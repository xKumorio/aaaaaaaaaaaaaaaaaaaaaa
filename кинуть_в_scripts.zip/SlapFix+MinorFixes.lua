--   ____    ___   _____  _____  ___  _  __
--  / ___|  / _ \ |  ___||_   _||_ _|| |/ /
--  \___ \ | | | || |_     | |   | | | ' /
--   ___) || |_| ||  _|    | |   | | | . \
--  |____/  \___/ |_|      |_|  |___||_|\_\
--
--   ___  _   _   ___   _   _  ___  ____   ___  _____   ___   ____
--  |_ _|| \ | | / _ \ | | | ||_ _|/ ___| |_ _||_   _| / _ \ |  _ \
--   | | |  \| || | | || | | | | | \___ \  | |   | |  | | | || |_) |
--   | | | |\  || |_| || |_| | | |  ___) | | |   | |  | |_| ||  _ <
--  |___||_| \_| \__\_\ \___/ |___||____/ |___|  |_|   \___/ |_| \_\
--
-- SlapFix + MinorFixes
-- Author: Softik_Inquisitor  (https://vk.ru/miurawr)

local CFG = {
  enabled = true,
  map = 'colmap.bin',
  respectFreeze = true,
  findZ = true,
  fallSyncRate = nil,
  log = false,
  debug = false,
  logFile = 'slapfix.log',
  onLanded = function(info) end,
}

local here = (debug.getinfo(1, 'S').source:gsub('^@', ''):match('^(.*[/\\])') or '')

local sampev = require 'samp.events'

local function crash(trace)
  print('[slapfix] error, closing RakSAMP: ' .. tostring(trace))
  exit()
end

local function guard(handler)
  return function(...)
    local result = { xpcall(handler, debug.traceback, ...) }
    if not result[1] then return crash(result[2]) end
    return unpack(result, 2, table.maxn(result))
  end
end

local rawRegisterHandler = registerHandler
local function registerHandler(event, handler)
  return rawRegisterHandler(event, guard(handler))
end
local colmap = (function()
local M = {}

M.VERSION = 9
M.PED_SPHERES = { -0.2, 0.2, 0.6 }
M.PED_RADIUS = 0.35
M.PED_SHIFT_DOWN = -0.5
M.PED_CEILING_Z = -0.867
M.PED_HEAD_STUCK_Z = -0.99
M.PED_HEAD_SINK = 0.05
M.PED_BOUND_RADIUS = 1.0
M.PED_HEAD_SPHERE = 3
M.PHYSICS_FRAME = 0.02
M.STATIC_FRAMES = 10
M.DRIVER_SYNC_HOLD = 1
M.FANOUT = 8
M.MODEL_CACHE = 8 * 1024 * 1024
M.OBJECT_CELL = 32
M.BIG_OBJECT_CELLS = 64
M.EDGE_EPS = 1e-6

local byte, floor, sqrt, abs = string.byte, math.floor, math.sqrt, math.abs
local sin, cos, rad, huge = math.sin, math.cos, math.rad, math.huge
local min, max = math.min, math.max

local function u16(s, p)
  local a, b = byte(s, p, p + 1)
  return a + b * 256
end

local function u32(s, p)
  local a, b, c, d = byte(s, p, p + 3)
  return a + b * 256 + c * 65536 + d * 16777216
end

local function i32(s, p)
  local v = u32(s, p)
  if v >= 2147483648 then v = v - 4294967296 end
  return v
end

local POW2 = {}
for e = 0, 254 do POW2[e] = 2 ^ (e - 150) end

local function f32(s, p)
  local a, b, c, d = byte(s, p, p + 3)
  local e = (d % 128) * 2 + floor(c / 128)
  local m = (c % 128) * 65536 + b * 256 + a
  local v
  if e == 0 then
    v = m * POW2[1]
  elseif e == 255 then
    v = m == 0 and huge or 0 / 0
  else
    v = (8388608 + m) * POW2[e]
  end
  if d >= 128 then return -v end
  return v
end

M._f32, M._u32 = f32, u32

local Map = {}
Map.__index = Map

function M.open(path, opts)
  opts = opts or {}
  local f, err = io.open(path, 'rb')
  if not f then return nil, err end
  local h = f:read(88)
  if not h or #h < 88 or h:sub(1, 4) ~= 'SFCM' then
    f:close()
    return nil, path .. ': not a colmap.bin'
  end
  if u32(h, 5) ~= M.VERSION then
    f:close()
    return nil, path .. ': colmap.bin version ' .. u32(h, 5) .. ', this reads ' .. M.VERSION .. ' - export it again'
  end
  local self = setmetatable({
    f = f,
    cellSize = f32(h, 9), cx0 = i32(h, 13), cy0 = i32(h, 17), ncx = u32(h, 21), ncy = u32(h, 25),
    refW = u32(h, 37), nInst = u32(h, 41), nWater = u32(h, 49), nModels = u32(h, 57), nNodes = u32(h, 65),
    nKnown = u32(h, 81),
    handling = {},
    modelCache = opts.modelCache or M.MODEL_CACHE,
    filterInterior = opts.filterInterior ~= false,
    clock = opts.clock or os.clock,
    models = {},
    modelBytes = 0,
    freeBytes = 0,
    tick = 0,
    gone = {}, goneGen = -1,
    objects = {},
    vehicles = {},
    peds = {},
    grid = {},
    big = {},
    movers = {},
    removals = {},
    interior = 0,
    gen = 0,
  }, Map)
  local function block(off, size)
    if size == 0 then return '' end
    f:seek('set', off)
    local s = f:read(size)
    if not s or #s ~= size then error(path .. ': colmap.bin is cut short - export it again', 0) end
    return s
  end
  local ok, e = pcall(function()
    self.starts = block(u32(h, 29), 4 * (self.ncx * self.ncy + 1))
    self.refs = block(u32(h, 33), self.refW * u32(self.starts, 4 * self.ncx * self.ncy + 1))
    self.inst = block(u32(h, 45), 80 * self.nInst)
    self.water = block(u32(h, 53), 36 * self.nWater)
    self.modelTable = block(u32(h, 61), 8 * self.nModels)
    self.nodes = block(u32(h, 69), 12 * self.nNodes)
    self.known = block(u32(h, 85), math.floor((self.nKnown + 7) / 8))
    local hs = block(u32(h, 77), 28 * u32(h, 73))
    for p = 1, #hs, 28 do
      self.handling[u32(hs, p)] = { mass = f32(hs, p + 4), turnMass = f32(hs, p + 8),
                                    cx = f32(hs, p + 12), cy = f32(hs, p + 16), cz = f32(hs, p + 20),
                                    kind = u32(hs, p + 24) }
    end
  end)
  if not ok then
    f:close()
    return nil, e
  end
  return self
end

function Map:close()
  if self.f then self.f:close() end
  self.f, self.models, self.modelBytes, self.freeBytes = nil, {}, 0, 0
end

local function readAt(self, off, size)
  self.f:seek('set', off)
  return self.f:read(size)
end

local function trimModels(self)
  while self.freeBytes > self.modelCache do
    local old, oldUsed = nil, huge
    for _, m in pairs(self.models) do
      if m.refs == 0 and m.used < oldUsed then old, oldUsed = m, m.used end
    end
    if not old then return end
    self.models[old.id] = nil
    self.modelBytes = self.modelBytes - #old.s
    self.freeBytes = self.freeBytes - #old.s
  end
end

local function getModel(self, id)
  local m = self.models[id]
  if not m then
    if id < 0 or id >= self.nModels then return nil end
    local p = id * 8 + 1
    local off, size = u32(self.modelTable, p), u32(self.modelTable, p + 4)
    if size == 0 then return nil end
    local s = readAt(self, off, size)
    m = { s = s, refs = 0, id = id, used = 0 }
    m.ox, m.oy, m.oz = f32(s, 1), f32(s, 5), f32(s, 9)
    m.sx, m.sy, m.sz = f32(s, 13), f32(s, 17), f32(s, 21)
    m.nv, m.nt, m.nch, m.w = u32(s, 25), u32(s, 29), u32(s, 33), u32(s, 37)
    local ns, nb = u32(s, 41), u32(s, 45)
    m.lo = { f32(s, 49), f32(s, 53), f32(s, 57) }
    m.hi = { f32(s, 61), f32(s, 65), f32(s, 69) }

    local levels, n, off2 = {}, m.nch, 73
    if n > 0 then
      levels[1] = { off = off2, n = n, rec = 20 }
      off2 = off2 + 20 * n
      while n > 1 do
        n = floor((n + M.FANOUT - 1) / M.FANOUT)
        levels[#levels + 1] = { off = off2, n = n, rec = 12 }
        off2 = off2 + 12 * n
      end
    end
    m.levels = levels
    m.vertOff = off2
    m.triOff = m.vertOff + 6 * m.nv
    local p = m.triOff + 3 * m.w * m.nt
    m.sph, m.box = {}, {}
    for i = 1, 4 * ns do
      m.sph[i] = f32(s, p)
      p = p + 4
    end
    for i = 1, 6 * nb do
      m.box[i] = f32(s, p)
      p = p + 4
    end
    self.models[id] = m
    self.modelBytes = self.modelBytes + #s
    self.freeBytes = self.freeBytes + #s
    trimModels(self)
  end
  self.tick = self.tick + 1
  m.used = self.tick
  return m
end

local function loadModel(self, id)
  local m = getModel(self, id)
  if not m then return nil end
  if m.refs == 0 then self.freeBytes = self.freeBytes - #m.s end
  m.refs = m.refs + 1
  return m
end

local function releaseModel(self, m)
  m.refs = m.refs - 1
  if m.refs == 0 then
    self.freeBytes = self.freeBytes + #m.s
    trimModels(self)
  end
end

local function slab(s, q, ox, oy, oz, ix, iy, iz, tmax)
  local l1, l2, l3, l4, l5, l6, h1, h2, h3, h4, h5, h6 = byte(s, q, q + 11)
  local t0, t1 = 0, tmax

  local lo, hi = l1 + l2 * 256 - 0.5, h1 + h2 * 256 + 0.5
  if ix then
    local a, b = (lo - ox) * ix, (hi - ox) * ix
    if a > b then a, b = b, a end
    if a > t0 then t0 = a end
    if b < t1 then t1 = b end
  elseif ox < lo or ox > hi then
    return false
  end
  if t0 > t1 then return false end
  lo, hi = l3 + l4 * 256 - 0.5, h3 + h4 * 256 + 0.5
  if iy then
    local a, b = (lo - oy) * iy, (hi - oy) * iy
    if a > b then a, b = b, a end
    if a > t0 then t0 = a end
    if b < t1 then t1 = b end
  elseif oy < lo or oy > hi then
    return false
  end
  if t0 > t1 then return false end
  lo, hi = l5 + l6 * 256 - 0.5, h5 + h6 * 256 + 0.5
  if iz then
    local a, b = (lo - oz) * iz, (hi - oz) * iz
    if a > b then a, b = b, a end
    if a > t0 then t0 = a end
    if b < t1 then t1 = b end
  elseif oz < lo or oz > hi then
    return false
  end
  return t0 <= t1
end

local stackL, stackI = {}, {}

local function modelRay(m, ox, oy, oz, dx, dy, dz, tmax)
  if m.nch == 0 then return nil end
  local s, w, levels, fan = m.s, m.w, m.levels, M.FANOUT
  local vertOff, triOff = m.vertOff, m.triOff
  local best = nil
  local eps = M.EDGE_EPS
  local ix = dx ~= 0 and 1 / dx or nil
  local iy = dy ~= 0 and 1 / dy or nil
  local iz = dz ~= 0 and 1 / dz or nil
  local n = 1
  stackL[1], stackI[1] = #levels, 0
  while n > 0 do
    local L, i = stackL[n], stackI[n]
    n = n - 1
    local lv = levels[L]
    local q = lv.off + lv.rec * i
    if slab(s, q, ox, oy, oz, ix, iy, iz, tmax) then
      if L > 1 then
        local c0 = fan * i
        local c1 = min(c0 + fan, levels[L - 1].n) - 1
        for c = c1, c0, -1 do
          n = n + 1
          stackL[n], stackI[n] = L - 1, c
        end
      else
        local first, count = u32(s, q + 12), u32(s, q + 16)
        for ti = first, first + count - 1 do
          local ia, ib, ic
          if w == 2 then
            local p = triOff + ti * 6
            local a1, a2, b1, b2, c1, c2 = byte(s, p, p + 5)
            ia, ib, ic = a1 + a2 * 256, b1 + b2 * 256, c1 + c2 * 256
          else
            local p = triOff + ti * 12
            ia, ib, ic = u32(s, p), u32(s, p + 4), u32(s, p + 8)
          end
          local p = vertOff + ia * 6
          local x1, x2, y1, y2, z1, z2 = byte(s, p, p + 5)
          local ax, ay, az = x1 + x2 * 256, y1 + y2 * 256, z1 + z2 * 256
          p = vertOff + ib * 6
          x1, x2, y1, y2, z1, z2 = byte(s, p, p + 5)
          local e1x, e1y, e1z = x1 + x2 * 256 - ax, y1 + y2 * 256 - ay, z1 + z2 * 256 - az
          p = vertOff + ic * 6
          x1, x2, y1, y2, z1, z2 = byte(s, p, p + 5)
          local e2x, e2y, e2z = x1 + x2 * 256 - ax, y1 + y2 * 256 - ay, z1 + z2 * 256 - az

          local px, py, pz = dy * e2z - dz * e2y, dz * e2x - dx * e2z, dx * e2y - dy * e2x
          local det = e1x * px + e1y * py + e1z * pz
          if det > 1e-12 or det < -1e-12 then
            local tx, ty, tz = ox - ax, oy - ay, oz - az
            local u = (tx * px + ty * py + tz * pz) / det
            if u >= -eps and u <= 1 + eps then
              local qx, qy, qz = ty * e1z - tz * e1y, tz * e1x - tx * e1z, tx * e1y - ty * e1x
              local v = (dx * qx + dy * qy + dz * qz) / det
              if v >= -eps and u + v <= 1 + eps then
                local t = (e2x * qx + e2y * qy + e2z * qz) / det
                if t >= -1e-6 and t <= tmax then
                  best, tmax = t, t
                end
              end
            end
          end
        end
      end
    end
  end
  return best
end

local function rayAlong(m, R, ox, oy, oz, x, y, z, dx, dy, dz, tmax)
  local wx, wy, wz = x - ox, y - oy, z - oz
  local lx = R[1] * wx + R[4] * wy + R[7] * wz
  local ly = R[2] * wx + R[5] * wy + R[8] * wz
  local lz = R[3] * wx + R[6] * wy + R[9] * wz
  local ldx = R[1] * dx + R[4] * dy + R[7] * dz
  local ldy = R[2] * dx + R[5] * dy + R[8] * dz
  local ldz = R[3] * dx + R[6] * dy + R[9] * dz
  local best = modelRay(m, (lx - m.ox) / m.sx, (ly - m.oy) / m.sy, (lz - m.oz) / m.sz,
    ldx / m.sx, ldy / m.sy, ldz / m.sz, tmax)
  if best then tmax = best end
  local sp = m.sph
  local a = ldx * ldx + ldy * ldy + ldz * ldz
  for i = 1, #sp, 4 do
    local cx, cy, cz, r = sp[i] - lx, sp[i + 1] - ly, sp[i + 2] - lz, sp[i + 3]
    local c = cx * cx + cy * cy + cz * cz - r * r
    if c > 0 then
      local b = cx * ldx + cy * ldy + cz * ldz
      local disc = b * b - a * c
      if disc >= 0 then
        local t = (b - sqrt(disc)) / a
        if t >= 0 and t <= tmax then best, tmax = t, t end
      end
    end
  end
  local bx = m.box
  for i = 1, #bx, 6 do
    local t0, t1 = 0, tmax
    local inside, hit = true, true
    for k = 0, 2 do
      local o = k == 0 and lx or k == 1 and ly or lz
      local d = k == 0 and ldx or k == 1 and ldy or ldz
      local lo, hi = bx[i + k], bx[i + 3 + k]
      if o < lo or o > hi then inside = false end
      if d == 0 then
        if o < lo or o > hi then hit = false end
      else
        local ta, tb = (lo - o) / d, (hi - o) / d
        if ta > tb then ta, tb = tb, ta end
        if ta > t0 then t0 = ta end
        if tb < t1 then t1 = tb end
      end
    end
    if hit and not inside and t0 <= t1 then best, tmax = t0, t0 end
  end
  return best
end

local function rayDown(m, R, ox, oy, oz, x, y, top, floorZ)
  local t = rayAlong(m, R, ox, oy, oz, x, y, top, 0, 0, -1, top - floorZ)
  return t and top - t or nil
end

local function closestOnTriangle(ax, ay, az, bx, by, bz, cx, cy, cz, px, py, pz)
  local abx, aby, abz = bx - ax, by - ay, bz - az
  local acx, acy, acz = cx - ax, cy - ay, cz - az
  local apx, apy, apz = px - ax, py - ay, pz - az
  local d1 = abx * apx + aby * apy + abz * apz
  local d2 = acx * apx + acy * apy + acz * apz
  if d1 <= 0 and d2 <= 0 then return ax, ay, az end
  local bpx, bpy, bpz = px - bx, py - by, pz - bz
  local d3 = abx * bpx + aby * bpy + abz * bpz
  local d4 = acx * bpx + acy * bpy + acz * bpz
  if d3 >= 0 and d4 <= d3 then return bx, by, bz end
  local vc = d1 * d4 - d3 * d2
  if vc <= 0 and d1 >= 0 and d3 <= 0 then
    local v = d1 / (d1 - d3)
    return ax + abx * v, ay + aby * v, az + abz * v
  end
  local cpx, cpy, cpz = px - cx, py - cy, pz - cz
  local d5 = abx * cpx + aby * cpy + abz * cpz
  local d6 = acx * cpx + acy * cpy + acz * cpz
  if d6 >= 0 and d5 <= d6 then return cx, cy, cz end
  local vb = d5 * d2 - d1 * d6
  if vb <= 0 and d2 >= 0 and d6 <= 0 then
    local w = d2 / (d2 - d6)
    return ax + acx * w, ay + acy * w, az + acz * w
  end
  local va = d3 * d6 - d5 * d4
  if va <= 0 and d4 - d3 >= 0 and d5 - d6 >= 0 then
    local w = (d4 - d3) / ((d4 - d3) + (d5 - d6))
    return bx + (cx - bx) * w, by + (cy - by) * w, bz + (cz - bz) * w
  end
  local k = 1 / (va + vb + vc)
  local v, w = vb * k, vc * k
  return ax + abx * v + acx * w, ay + aby * v + acy * w, az + abz * v + acz * w
end

local function sphereModel(m, R, ox, oy, oz, px, py, pz, r)
  local wx, wy, wz = px - ox, py - oy, pz - oz
  local lx = R[1] * wx + R[4] * wy + R[7] * wz
  local ly = R[2] * wx + R[5] * wy + R[8] * wz
  local lz = R[3] * wx + R[6] * wy + R[9] * wz
  local best, depth, ex, ey, ez, cpx, cpy, cpz = huge, nil, nil, nil, nil, nil, nil, nil
  local sp = m.sph
  for i = 1, #sp, 4 do
    local rb = sp[i + 3]
    local dx, dy, dz = lx - sp[i], ly - sp[i + 1], lz - sp[i + 2]
    local d2 = dx * dx + dy * dy + dz * dz
    if d2 < (r + rb) * (r + rb) then
      local dist = sqrt(d2)
      local touch = max(dist - rb, 0)
      if touch * touch < best and touch < r then
        best = touch * touch
        if dist > 0 then
          ex, ey, ez = dx / dist, dy / dist, dz / dist
        else
          ex, ey, ez = 1, 0, 0
        end
        depth = r - (dist - rb)
        cpx, cpy, cpz = lx - ex * touch, ly - ey * touch, lz - ez * touch
      end
    end
  end
  local bx = m.box
  for i = 1, #bx, 6 do
    local x0, y0, z0, x1, y1, z1 = bx[i], bx[i + 1], bx[i + 2], bx[i + 3], bx[i + 4], bx[i + 5]
    if lx + r >= x0 and lx - r <= x1 and ly + r >= y0 and ly - r <= y1 and lz + r >= z0 and lz - r <= z1 then
      if lx >= x0 and lx <= x1 and ly >= y0 and ly <= y1 and lz >= z0 and lz <= z1 then
        local ax = lx - (x0 + x1) * 0.5 <= 0 and lx - x0 or x1 - lx
        local ay = ly - (y0 + y1) * 0.5 <= 0 and ly - y0 or y1 - ly
        local az = lz - (z0 + z1) * 0.5 <= 0 and lz - z0 or z1 - lz
        local nx, ny, nz, pd = 0, 0, 0, nil
        if ax < ay and ax < az then
          nx, pd = lx - (x0 + x1) * 0.5 <= 0 and -1 or 1, ax
        elseif ay < ax and ay < az then
          ny, pd = ly - (y0 + y1) * 0.5 <= 0 and -1 or 1, ay
        else
          nz, pd = lz - (z0 + z1) * 0.5 <= 0 and -1 or 1, az
        end
        best, ex, ey, ez, depth = 0, nx, ny, nz, pd + r
        cpx, cpy, cpz = lx - nx * r, ly - ny * r, lz - nz * r
      else
        local qx = lx < x0 and x0 or lx > x1 and x1 or lx
        local qy = ly < y0 and y0 or ly > y1 and y1 or ly
        local qz = lz < z0 and z0 or lz > z1 and z1 or lz
        local dx, dy, dz = lx - qx, ly - qy, lz - qz
        local d2 = dx * dx + dy * dy + dz * dz
        if d2 < best and d2 < r * r and d2 > 0 then
          local dist = sqrt(d2)
          best, ex, ey, ez, depth = d2, dx / dist, dy / dist, dz / dist, r - dist
          cpx, cpy, cpz = qx, qy, qz
        end
      end
    end
  end
  local s, w, levels, fan = m.s, m.w, m.levels, M.FANOUT
  local vertOff, triOff = m.vertOff, m.triOff
  local mx, my, mz, sx, sy, sz = m.ox, m.oy, m.oz, m.sx, m.sy, m.sz
  local qx, qy, qz = (lx - mx) / sx, (ly - my) / sy, (lz - mz) / sz
  local rx, ry, rz = r / sx + 0.5, r / sy + 0.5, r / sz + 0.5
  local n = m.nch > 0 and 1 or 0
  stackL[1], stackI[1] = #levels, 0
  while n > 0 do
    local L, i = stackL[n], stackI[n]
    n = n - 1
    local lv = levels[L]
    local q = lv.off + lv.rec * i
    local l1, l2, l3, l4, l5, l6, h1, h2, h3, h4, h5, h6 = byte(s, q, q + 11)
    if qx + rx >= l1 + l2 * 256 and qx - rx <= h1 + h2 * 256
        and qy + ry >= l3 + l4 * 256 and qy - ry <= h3 + h4 * 256
        and qz + rz >= l5 + l6 * 256 and qz - rz <= h5 + h6 * 256 then
      if L > 1 then
        local c0 = fan * i
        local c1 = min(c0 + fan, levels[L - 1].n) - 1
        for c = c1, c0, -1 do
          n = n + 1
          stackL[n], stackI[n] = L - 1, c
        end
      else
        local first, count = u32(s, q + 12), u32(s, q + 16)
        for ti = first, first + count - 1 do
          local ia, ib, ic
          if w == 2 then
            local p = triOff + ti * 6
            local a1, a2, b1, b2, c1, c2 = byte(s, p, p + 5)
            ia, ib, ic = a1 + a2 * 256, b1 + b2 * 256, c1 + c2 * 256
          else
            local p = triOff + ti * 12
            ia, ib, ic = u32(s, p), u32(s, p + 4), u32(s, p + 8)
          end
          local p = vertOff + ia * 6
          local x1, x2, y1, y2, z1, z2 = byte(s, p, p + 5)
          local ax, ay, az = (x1 + x2 * 256) * sx + mx, (y1 + y2 * 256) * sy + my, (z1 + z2 * 256) * sz + mz
          p = vertOff + ib * 6
          x1, x2, y1, y2, z1, z2 = byte(s, p, p + 5)
          local bx, by, bz = (x1 + x2 * 256) * sx + mx, (y1 + y2 * 256) * sy + my, (z1 + z2 * 256) * sz + mz
          p = vertOff + ic * 6
          x1, x2, y1, y2, z1, z2 = byte(s, p, p + 5)
          local cx, cy, cz = (x1 + x2 * 256) * sx + mx, (y1 + y2 * 256) * sy + my, (z1 + z2 * 256) * sz + mz
          cx, cy, cz = closestOnTriangle(ax, ay, az, bx, by, bz, cx, cy, cz, lx, ly, lz)
          local dx, dy, dz = lx - cx, ly - cy, lz - cz
          local d2 = dx * dx + dy * dy + dz * dz
          if d2 < best and d2 < r * r and d2 > 0 then
            local dist = sqrt(d2)
            best, ex, ey, ez, depth = d2, dx / dist, dy / dist, dz / dist, r - dist
            cpx, cpy, cpz = cx, cy, cz
          end
        end
      end
    end
  end
  if not ex then return nil end
  return depth, R[1] * ex + R[2] * ey + R[3] * ez, R[4] * ex + R[5] * ey + R[6] * ez, R[7] * ex + R[8] * ey + R[9] * ez,
    ox + R[1] * cpx + R[2] * cpy + R[3] * cpz, oy + R[4] * cpx + R[5] * cpy + R[6] * cpz,
    oz + R[7] * cpx + R[8] * cpy + R[9] * cpz
end

local function isGone(self, k)
  if self.goneGen ~= self.gen then self.gone, self.goneGen = {}, self.gen end
  local g = self.gone[k]
  if g ~= nil then return g end
  local s, p = self.inst, 80 * k + 1
  local bi = byte(s, p + 4)
  g = self.filterInterior and bi ~= self.interior and bi ~= 13
  if not g then
    local model = i32(s, p)
    local x, y, z = f32(s, p + 8), f32(s, p + 12), f32(s, p + 16)
    local rem = self.removals
    for i = 1, #rem do
      local r = rem[i]
      if r[1] == -1 or r[1] == model then
        local dx, dy, dz = x - r[2], y - r[3], z - r[4]
        if dx * dx + dy * dy + dz * dz <= r[5] * r[5] then
          g = true
          break
        end
      end
    end
  end
  self.gone[k] = g
  return g
end

local function waterAt(self, i, x, y)
  local s, p = self.water, 36 * i + 1
  local ax, ay, az = f32(s, p), f32(s, p + 4), f32(s, p + 8)
  local bx, by, bz = f32(s, p + 12), f32(s, p + 16), f32(s, p + 20)
  local cx, cy, cz = f32(s, p + 24), f32(s, p + 28), f32(s, p + 32)
  local d = (bx - ax) * (cy - ay) - (by - ay) * (cx - ax)
  if d == 0 then return nil end
  local wa = ((bx - x) * (cy - y) - (by - y) * (cx - x)) / d
  local wb = ((cx - x) * (ay - y) - (cy - y) * (ax - x)) / d
  local wc = 1 - wa - wb
  local eps = M.EDGE_EPS
  if wa < -eps or wb < -eps or wc < -eps then return nil end
  return wa * az + wb * bz + wc * cz
end

local function placementRotation(s, p)
  return {
    f32(s, p + 20), f32(s, p + 24), f32(s, p + 28),
    f32(s, p + 32), f32(s, p + 36), f32(s, p + 40),
    f32(s, p + 44), f32(s, p + 48), f32(s, p + 52),
  }
end

local function refAt(self, r)
  if self.refW == 4 then return u32(self.refs, 4 * r + 1) end
  return u16(self.refs, 2 * r + 1)
end

local function mapProbe(self, x, y, top)
  local cx, cy = floor(x / self.cellSize) - self.cx0, floor(y / self.cellSize) - self.cy0
  if cx < 0 or cy < 0 or cx >= self.ncx or cy >= self.ncy then return nil, nil end
  local c = cy * self.ncx + cx
  local first, last = u32(self.starts, 4 * c + 1), u32(self.starts, 4 * c + 5) - 1
  local refs, wide, s, nInst = self.refs, self.refW == 4, self.inst, self.nInst
  local ground, water, floorZ, model, int = nil, nil, -1e4, nil, nil
  for r = first, last do
    local k
    if wide then k = u32(refs, 4 * r + 1) else k = u16(refs, 2 * r + 1) end
    if k >= nInst then
      local h = waterAt(self, k - nInst, x, y)
      if h and h <= top and (not water or h > water) then water = h end
    else
      local p = 80 * k + 1
      if f32(s, p + 76) < floorZ then break end
      if x >= f32(s, p + 56) and x <= f32(s, p + 68) and y >= f32(s, p + 60) and y <= f32(s, p + 72)
          and f32(s, p + 64) <= top and not isGone(self, k) then
        local m = getModel(self, i32(s, p))
        if m then
          local h = rayDown(m, placementRotation(s, p), f32(s, p + 8), f32(s, p + 12), f32(s, p + 16),
            x, y, top, floorZ)
          if h and h > floorZ then floorZ, ground, model, int = h, h, m.id, byte(s, p + 4) end
        end
      end
    end
  end
  return ground, water, model, int
end

function Map:waterLevel(x, y)
  local cx, cy = floor(x / self.cellSize) - self.cx0, floor(y / self.cellSize) - self.cy0
  if cx < 0 or cy < 0 or cx >= self.ncx or cy >= self.ncy then return nil end
  local c = cy * self.ncx + cx
  local water
  for r = u32(self.starts, 4 * c + 1), u32(self.starts, 4 * c + 5) - 1 do
    local k = refAt(self, r)
    if k >= self.nInst then
      local h = waterAt(self, k - self.nInst, x, y)
      if h and (not water or h > water) then water = h end
    end
  end
  return water
end

function M.rotation(rx, ry, rz)
  local x, y, z = rad(rx or 0), rad(ry or 0), rad(rz or 0)
  local cx, sx, cy, sy, cz, sz = cos(x), sin(x), cos(y), sin(y), cos(z), sin(z)
  return {
    cz * cy - sz * sx * sy, -sz * cx, cz * sy + sz * sx * cy,
    sz * cy + cz * sx * sy, cz * cx, sz * sy - cz * sx * cy,
    -cx * sy, sx, cx * cy,
  }
end

function M.headingRotation(deg)
  local a = rad(deg or 0)
  local c, s = cos(a), sin(a)
  return { c, -s, 0, s, c, 0, 0, 0, 1 }
end

function M.quatRotation(w, x, y, z)
  x, y, z = -x, -y, -z
  local n = w * w + x * x + y * y + z * z
  if n < 1e-8 then return { 1, 0, 0, 0, 1, 0, 0, 0, 1 } end
  local s = 2 / n
  return {
    1 - s * (y * y + z * z), s * (x * y - z * w), s * (x * z + y * w),
    s * (x * y + z * w), 1 - s * (x * x + z * z), s * (y * z - x * w),
    s * (x * z - y * w), s * (y * z + x * w), 1 - s * (x * x + y * y),
  }
end

function M.axesRotation(rx, ry, rz, fx, fy, fz)
  local ux, uy, uz = ry * fz - rz * fy, rz * fx - rx * fz, rx * fy - ry * fx
  return { rx, fx, ux, ry, fy, uy, rz, fz, uz }
end

local function objectBox(o)
  local m, R = o.model, o.R
  local lo, hi = m.lo, m.hi
  local bx0, by0, bz0, bx1, by1, bz1 = huge, huge, huge, -huge, -huge, -huge
  for k = 0, 7 do
    local x = k % 2 == 0 and lo[1] or hi[1]
    local y = floor(k / 2) % 2 == 0 and lo[2] or hi[2]
    local z = k < 4 and lo[3] or hi[3]
    local wx = o.x + R[1] * x + R[2] * y + R[3] * z
    local wy = o.y + R[4] * x + R[5] * y + R[6] * z
    local wz = o.z + R[7] * x + R[8] * y + R[9] * z
    bx0, bx1 = min(bx0, wx), max(bx1, wx)
    by0, by1 = min(by0, wy), max(by1, wy)
    bz0, bz1 = min(bz0, wz), max(bz1, wz)
  end
  o.box = { bx0, by0, bz0, bx1, by1, bz1 }
end

local function gridKey(cx, cy) return cx * 65536 + cy end
local function unlink(self, o)
  if o.cells then
    for _, key in ipairs(o.cells) do
      local c = self.grid[key]
      if c then
        c[o] = nil
        if next(c) == nil then self.grid[key] = nil end
      end
    end
  end
  o.cells = nil
  self.big[o], self.movers[o] = nil, nil
end

local function link(self, o)
  unlink(self, o)
  if o.move then
    self.movers[o] = true
    return
  end
  objectBox(o)
  local b, cs = o.box, M.OBJECT_CELL
  local cx0, cx1 = floor(b[1] / cs), floor(b[4] / cs)
  local cy0, cy1 = floor(b[2] / cs), floor(b[5] / cs)
  if (cx1 - cx0 + 1) * (cy1 - cy0 + 1) > M.BIG_OBJECT_CELLS then
    self.big[o] = true
    return
  end
  o.cells = {}
  for cx = cx0, cx1 do
    for cy = cy0, cy1 do
      local key = gridKey(cx, cy)
      local c = self.grid[key]
      if not c then
        c = {}
        self.grid[key] = c
      end
      c[o] = true
      o.cells[#o.cells + 1] = key
    end
  end
end

local function place(o, x, y, z, rx, ry, rz)
  o.x, o.y, o.z = x, y, z
  o.rx, o.ry, o.rz = rx or 0, ry or 0, rz or 0
  o.R = M.rotation(o.rx, o.ry, o.rz)
end

function Map:modelInGame(model)
  if model < 0 or model >= self.nKnown then return false end
  local byte = self.known:byte(floor(model / 8) + 1)
  return floor(byte / 2 ^ (model % 8)) % 2 == 1
end

function Map:addObject(id, model, x, y, z, rx, ry, rz)
  self:removeObject(id)
  local m = loadModel(self, model)
  if not m then return false end
  local o = { id = id, model = m }
  place(o, x, y, z, rx, ry, rz)
  self.objects[id] = o
  link(self, o)
  return true
end

function Map:removeObject(id)
  local o = self.objects[id]
  if not o then return end
  unlink(self, o)
  releaseModel(self, o.model)
  self.objects[id] = nil
end

function Map:setObjectPos(id, x, y, z)
  local o = self.objects[id]
  if not o then return end
  o.move = nil
  place(o, x, y, z, o.rx, o.ry, o.rz)
  link(self, o)
end

function Map:setObjectRot(id, rx, ry, rz)
  local o = self.objects[id]
  if not o then return end
  o.move = nil
  place(o, o.x, o.y, o.z, rx, ry, rz)
  link(self, o)
end

function Map:moveObject(id, x, y, z, speed, rx, ry, rz, now)
  local o = self.objects[id]
  if not o then return end
  now = now or self.clock()
  local here = { self:objectPos(id, now) }
  place(o, here[1], here[2], here[3], here[4], here[5], here[6])
  local function to(a, b) return (b == nil or b == -1000) and a or b end
  local d = sqrt((x - o.x) ^ 2 + (y - o.y) ^ 2 + (z - o.z) ^ 2)
  local dur = (speed and speed > 0) and d / speed or 0
  local trx, try, trz = to(o.rx, rx), to(o.ry, ry), to(o.rz, rz)
  if dur <= 0 then
    place(o, x, y, z, trx, try, trz)
    o.move = nil
  else
    o.move = { o.x, o.y, o.z, o.rx, o.ry, o.rz, x, y, z, trx, try, trz, t0 = now, dur = dur }
  end
  link(self, o)
end

function Map:stopObject(id, now)
  local o = self.objects[id]
  if not o or not o.move then return end
  local x, y, z, rx, ry, rz = self:objectPos(id, now)
  o.move = nil
  place(o, x, y, z, rx, ry, rz)
  link(self, o)
end

function Map:objectPos(id, now)
  local o = self.objects[id]
  if not o then return nil end
  local mv = o.move
  if not mv then return o.x, o.y, o.z, o.rx, o.ry, o.rz end
  local k = min(1, max(0, ((now or self.clock()) - mv.t0) / mv.dur))
  local function l(i) return mv[i] + (mv[i + 6] - mv[i]) * k end
  return l(1), l(2), l(3), l(4), l(5), l(6)
end

local function settle(self, now)
  for o in pairs(self.movers) do
    if now >= o.move.t0 + o.move.dur then
      local mv = o.move
      o.move = nil
      place(o, mv[7], mv[8], mv[9], mv[10], mv[11], mv[12])
      link(self, o)
    end
  end
end

function Map:probe(x, y, z, now)
  local top = z + 1e-3
  local ground, water, model, int = mapProbe(self, x, y, top)
  local what, objectId = ground and 'map' or nil, nil
  now = now or self.clock()
  if next(self.movers) then settle(self, now) end
  local floorZ = ground or -1e4
  local function try(o, R, ox, oy, oz)
    if o.interior and o.interior ~= self.interior then return end
    if o.kind == 'vehicle' and o.id == self.ignored then return end
    local h = rayDown(o.model, R, ox, oy, oz, x, y, top, floorZ)
    if h and h > floorZ then
      floorZ, ground, what, model, int, objectId = h, h, o.kind or 'object', o.model.id, nil, o.id
    end
  end
  local c = self.grid[gridKey(floor(x / M.OBJECT_CELL), floor(y / M.OBJECT_CELL))]
  if c then
    for o in pairs(c) do
      local b = o.box
      if x >= b[1] and x <= b[4] and y >= b[2] and y <= b[5] and b[3] <= top and b[6] >= floorZ then
        try(o, o.R, o.x, o.y, o.z)
      end
    end
  end
  for o in pairs(self.big) do
    local b = o.box
    if x >= b[1] and x <= b[4] and y >= b[2] and y <= b[5] and b[3] <= top and b[6] >= floorZ then
      try(o, o.R, o.x, o.y, o.z)
    end
  end
  for o in pairs(self.movers) do
    local ox, oy, oz, rx, ry, rz = self:objectPos(o.id, now)
    try(o, M.rotation(rx, ry, rz), ox, oy, oz)
  end
  return ground, water, what, model, int, objectId
end

local function isStatic(self, o, now)
  if o.kind ~= 'vehicle' then return true end
  return o.svx == 0 and o.svy == 0 and o.svz == 0 and now - o.movedAt >= M.STATIC_FRAMES * M.PHYSICS_FRAME
end

function Map:pedContacts(x, y, z, now, standing, mvx, mvy, list)
  local spheres, r = M.PED_SPHERES, M.PED_RADIUS
  local bx0, bx1, by0, by1 = x - r, x + r, y - r, y + r
  local bz0, bz1 = z + spheres[1] - r, z + spheres[#spheres] + r
  local sx, sy, sz, depth, count = 0, 0, 0, 0, 0
  local hitKind, hitModel, hitId, ceiling, sink
  now = now or self.clock()
  local function touch(kind, m, id, R, ox, oy, oz, static)
    for i, off in ipairs(spheres) do
      local d, nx, ny, nz = sphereModel(m, R, ox, oy, oz, x, y, z + off, r)
      if d then
        if nz < M.PED_CEILING_Z then ceiling = true end
        if standing and (static or kind == 'vehicle' and id ~= standing) then
          if static and i == M.PED_HEAD_SPHERE and nz < M.PED_HEAD_STUCK_Z then
            local sp = max(sqrt((mvx or 0) ^ 2 + (mvy or 0) ^ 2), 0.001)
            nx, ny = -(mvx or 0) / sp, -(mvy or 0) / sp
            sink = true
          else
            local h = sqrt(nx * nx + ny * ny)
            if h ~= 0 then nx, ny = nx / h, ny / h end
            if not static and nz > 0 then nz = 0 end
          end
          local l = sqrt(nx * nx + ny * ny + nz * nz)
          nx, ny, nz = nx / l, ny / l, nz / l
        end
        sx, sy, sz, count = sx + nx, sy + ny, sz + nz, count + 1
        if d > depth then depth, hitKind, hitModel, hitId = d, kind, m.id, id end
        if list then list[#list + 1] = { kind = kind, nx = nx, ny = ny, nz = nz } end
      end
    end
  end
  local s, cs, seen = self.inst, self.cellSize, {}
  for cy = max(floor(by0 / cs) - self.cy0, 0), min(floor(by1 / cs) - self.cy0, self.ncy - 1) do
    for cx = max(floor(bx0 / cs) - self.cx0, 0), min(floor(bx1 / cs) - self.cx0, self.ncx - 1) do
      local c = cy * self.ncx + cx
      for ri = u32(self.starts, 4 * c + 1), u32(self.starts, 4 * c + 5) - 1 do
        local k = refAt(self, ri)
        if k < self.nInst and not seen[k] then
          seen[k] = true
          local p = 80 * k + 1
          if f32(s, p + 56) <= bx1 and f32(s, p + 68) >= bx0 and f32(s, p + 60) <= by1 and f32(s, p + 72) >= by0
              and f32(s, p + 64) <= bz1 and f32(s, p + 76) >= bz0 and not isGone(self, k) then
            local m = getModel(self, i32(s, p))
            if m then
              touch('map', m, nil, placementRotation(s, p), f32(s, p + 8), f32(s, p + 12), f32(s, p + 16), true)
            end
          end
        end
      end
    end
  end
  if next(self.movers) then settle(self, now) end
  local done = {}
  local function body(o)
    if done[o] or (o.interior and o.interior ~= self.interior) then return end
    if o.kind == 'vehicle' and o.id == self.ignored then return end
    done[o] = true
    local b = o.box
    if b[1] <= bx1 and b[4] >= bx0 and b[2] <= by1 and b[5] >= by0 and b[3] <= bz1 and b[6] >= bz0 then
      touch(o.kind or 'object', o.model, o.id, o.R, o.x, o.y, o.z, isStatic(self, o, now))
    end
  end
  local oc = M.OBJECT_CELL
  for cx = floor(bx0 / oc), floor(bx1 / oc) do
    for cy = floor(by0 / oc), floor(by1 / oc) do
      local c = self.grid[gridKey(cx, cy)]
      if c then
        for o in pairs(c) do body(o) end
      end
    end
  end
  for o in pairs(self.big) do body(o) end
  for o in pairs(self.movers) do
    local ox, oy, oz, rx, ry, rz = self:objectPos(o.id, now)
    touch('object', o.model, o.id, M.rotation(rx, ry, rz), ox, oy, oz, false)
  end
  local tall = spheres[#spheres] - spheres[1] + 2 * r
  for id, p in pairs(self.peds) do
    local dx, dy = x - p.x, y - p.y
    local d = sqrt(dx * dx + dy * dy)
    if d >= r and d < 2 * r and abs(z - p.z) < tall then
      local nx, ny = dx / d, dy / d
      sx, sy, count = sx + nx, sy + ny, count + 1
      if 2 * r - d > depth then depth, hitKind, hitModel, hitId = 2 * r - d, 'player', 0, id end
      if list then list[#list + 1] = { kind = 'player', id = id, nx = nx, ny = ny, nz = 0 } end
    end
  end
  return count, sx, sy, sz, depth, hitKind, hitModel, hitId, ceiling, sink
end

function Map:shiftPed(x, y, z, now, standing, mvx, mvy)
  local count, sx, sy, sz, depth, kind, model, id, _, sink = self:pedContacts(x, y, z, now, standing, mvx, mvy)
  if count == 0 then return x, y, z end
  if sink then z = z - M.PED_HEAD_SINK end
  local mag = sqrt(sx * sx + sy * sy + sz * sz)
  if mag > 1 then sx, sy, sz = sx / mag, sy / mag, sz / mag end
  local k
  if sz >= M.PED_SHIFT_DOWN then
    k = 1.5 * depth
    if k >= 0.005 then
      if k > 0.3 then k = k + 0.3 * depth end
    else
      k = k + 0.005 * depth
    end
  else
    k = 0.75 * depth
  end
  return x + sx * k, y + sy * k, z + sz * k, { kind = kind, model = model, id = id, depth = depth,
                                                  nx = sx, ny = sy, nz = sz }
end

function Map:nearby(x, y, z, radius, now)
  local s, cs = self.inst, self.cellSize
  local byInterior, seen = {}, {}
  for cy = max(floor((y - radius) / cs) - self.cy0, 0), min(floor((y + radius) / cs) - self.cy0, self.ncy - 1) do
    for cx = max(floor((x - radius) / cs) - self.cx0, 0), min(floor((x + radius) / cs) - self.cx0, self.ncx - 1) do
      local c = cy * self.ncx + cx
      for r = u32(self.starts, 4 * c + 1), u32(self.starts, 4 * c + 5) - 1 do
        local k = refAt(self, r)
        if k < self.nInst and not seen[k] then
          seen[k] = true
          local p = 80 * k + 1
          local bx0, by0, bz0 = f32(s, p + 56), f32(s, p + 60), f32(s, p + 64)
          local bx1, by1, bz1 = f32(s, p + 68), f32(s, p + 72), f32(s, p + 76)
          local ex = max(bx0 - x, 0, x - bx1)
          local ey = max(by0 - y, 0, y - by1)
          if ex * ex + ey * ey <= radius * radius then
            local int = byte(s, p + 4)
            local g = byInterior[int]
            if not g then
              g = { interior = int, count = 0, removed = 0, zmin = huge, zmax = -huge }
              byInterior[int] = g
            end
            g.count = g.count + 1
            if self.removals[1] and isGone(self, k) and (int == self.interior or int == 13) then
              g.removed = g.removed + 1
            end
            g.zmin, g.zmax = min(g.zmin, bz0), max(g.zmax, bz1)
          end
        end
      end
    end
  end
  local groups = {}
  for _, g in pairs(byInterior) do groups[#groups + 1] = g end
  table.sort(groups, function(a, b) return a.interior < b.interior end)
  now = now or self.clock()
  local objects, total = {}, 0
  for id, o in pairs(self.objects) do
    total = total + 1
    local ox, oy, oz = self:objectPos(id, now)
    local d = sqrt((ox - x) ^ 2 + (oy - y) ^ 2 + (oz - z) ^ 2)
    if d <= radius then
      objects[#objects + 1] = { kind = 'object', id = id, model = o.model.id, dist = d, z = oz,
                                top = o.box and o.box[6] }
    end
  end
  for id, v in pairs(self.vehicles) do
    local d = sqrt((v.x - x) ^ 2 + (v.y - y) ^ 2 + (v.z - z) ^ 2)
    if d <= radius then
      objects[#objects + 1] = { kind = 'vehicle', id = id, model = v.modelId, dist = d, z = v.z,
                                top = v.box and v.box[6], interior = v.interior }
    end
  end
  for id, p in pairs(self.peds) do
    local d = sqrt((p.x - x) ^ 2 + (p.y - y) ^ 2 + (p.z - z) ^ 2)
    if d <= radius then
      objects[#objects + 1] = { kind = 'player', id = id, model = 0, dist = d, z = p.z, top = p.z + 0.95 }
    end
  end
  table.sort(objects, function(a, b) return a.dist < b.dist end)
  return groups, objects, total
end

M.PATH_AREA = 750
M.PATH_ORIGIN = -3000

local function pathArea(v)
  return floor((v - M.PATH_ORIGIN) / M.PATH_AREA)
end

function Map:nearestPedNode(x, y, z, loadRadius)
  local ax0, ax1 = pathArea(x - loadRadius), pathArea(x + loadRadius)
  local ay0, ay1 = pathArea(y - loadRadius), pathArea(y + loadRadius)
  local s, best, bx, by, bz = self.nodes, huge, nil, nil, nil
  for i = 0, self.nNodes - 1 do
    local p = 12 * i + 1
    local nx, ny = f32(s, p), f32(s, p + 4)
    local ax, ay = pathArea(nx), pathArea(ny)
    if ax >= ax0 and ax <= ax1 and ay >= ay0 and ay <= ay1 then
      local nz = f32(s, p + 8)
      local d = (nx - x) ^ 2 + (ny - y) ^ 2 + (nz - z) ^ 2
      if d < best then best, bx, by, bz = d, nx, ny, nz end
    end
  end
  return bx, by, bz
end

function Map:groundTop(x, y, from)
  return self:probe(x, y, from or 1000)
end

function Map:removeBuilding(model, x, y, z, radius)
  self.removals[#self.removals + 1] = { model, x, y, z, radius }
  self.gen = self.gen + 1
end

function Map:setInterior(id)
  id = id or 0
  if id ~= self.interior then
    self.interior = id
    self.gen = self.gen + 1
  end
end

function Map:setVehicle(id, model, x, y, z, R, interior, now)
  local v = self.vehicles[id]
  if v and v.modelId ~= model then
    self:removeVehicle(id)
    v = nil
  end
  if not v then
    local m = loadModel(self, model)
    if not m then return false end
    v = { id = id, kind = 'vehicle', model = m, modelId = model, interior = interior or 0 }
    self.vehicles[id] = v
  end
  now = self.clock()
  v.x, v.y, v.z, v.R = x, y, z, R
  v.sx, v.sy, v.sz, v.svx, v.svy, v.svz, v.syncT, v.movedAt = x, y, z, 0, 0, 0, now, now
  v.period, v.synced, v.driver = 0, false, nil
  v.teleports = (v.teleports or 0) + 1
  if interior then v.interior = interior end
  link(self, v)
  return true
end

local function syncWindow(v)
  return v.driver and M.DRIVER_SYNC_HOLD or v.period
end

function Map:vehiclePredicted(id, now)
  local v = self.vehicles[id]
  if not v then return nil end
  local f = min((now or self.clock()) - v.syncT, syncWindow(v)) / M.PHYSICS_FRAME
  return v.sx + v.svx * f, v.sy + v.svy * f, v.sz + v.svz * f
end

function Map:moveVehicle(id, x, y, z, R, speed, now)
  local v = self.vehicles[id]
  if not v then return false end
  now = now or self.clock()
  if x ~= v.x or y ~= v.y or z ~= v.z then v.movedAt = now end
  local gap = now - v.syncT
  v.period = speed and v.synced and gap <= M.DRIVER_SYNC_HOLD and gap or 0
  v.synced = speed ~= nil
  v.x, v.y, v.z, v.sx, v.sy, v.sz, v.syncT = x, y, z, x, y, z, now
  v.svx, v.svy, v.svz = speed and speed.x or 0, speed and speed.y or 0, speed and speed.z or 0
  if R then v.R = R end
  link(self, v)
  return true
end

function Map:setVehicleDriver(id, playerId)
  local v = self.vehicles[id]
  if v then v.driver = playerId end
end

function Map:playerLeftVehicles(playerId)
  for _, v in pairs(self.vehicles) do
    if v.driver == playerId then v.driver = nil end
  end
end

function Map:vehicleSpeed(v, now)
  if now - v.syncT > syncWindow(v) + M.PHYSICS_FRAME then return 0, 0, 0 end
  return v.svx, v.svy, v.svz
end

function Map:vehicleContacts(x, y, z, now)
  local spheres, r = M.PED_SPHERES, M.PED_RADIUS
  local bx0, bx1, by0, by1 = x - r, x + r, y - r, y + r
  local bz0, bz1 = z + spheres[1] - r, z + spheres[#spheres] + r
  local list = {}
  for _, v in pairs(self.vehicles) do
    local b = v.box
    if v.interior == self.interior and v.id ~= self.ignored and b[1] <= bx1 and b[4] >= bx0 and b[2] <= by1
        and b[5] >= by0 and b[3] <= bz1 and b[6] >= bz0 then
      for _, off in ipairs(spheres) do
        local d, nx, ny, nz, px, py, pz = sphereModel(v.model, v.R, v.x, v.y, v.z, x, y, z + off, r)
        if d then
          list[#list + 1] = { v = v, depth = d, nx = nx, ny = ny, nz = nz, px = px, py = py, pz = pz }
        end
      end
    end
  end
  return list
end

function Map:segmentHit(x0, y0, z0, x1, y1, z1, now, skipVehicle)
  local dx, dy, dz = x1 - x0, y1 - y0, z1 - z0
  local len = sqrt(dx * dx + dy * dy + dz * dz)
  if len == 0 then return nil end
  dx, dy, dz = dx / len, dy / len, dz / len
  local bx0, bx1 = min(x0, x1), max(x0, x1)
  local by0, by1 = min(y0, y1), max(y0, y1)
  local bz0, bz1 = min(z0, z1), max(z0, z1)
  local best, kind, id, model = len, nil, nil, nil
  local function try(m, R, ox, oy, oz, k, i)
    local t = rayAlong(m, R, ox, oy, oz, x0, y0, z0, dx, dy, dz, best)
    if t and t < best then best, kind, id, model = t, k, i, m.id end
  end
  local s, cs, seen = self.inst, self.cellSize, {}
  for cy = max(floor(by0 / cs) - self.cy0, 0), min(floor(by1 / cs) - self.cy0, self.ncy - 1) do
    for cx = max(floor(bx0 / cs) - self.cx0, 0), min(floor(bx1 / cs) - self.cx0, self.ncx - 1) do
      local c = cy * self.ncx + cx
      for ri = u32(self.starts, 4 * c + 1), u32(self.starts, 4 * c + 5) - 1 do
        local k = refAt(self, ri)
        if k < self.nInst and not seen[k] then
          seen[k] = true
          local p = 80 * k + 1
          if f32(s, p + 56) <= bx1 and f32(s, p + 68) >= bx0 and f32(s, p + 60) <= by1 and f32(s, p + 72) >= by0
              and f32(s, p + 64) <= bz1 and f32(s, p + 76) >= bz0 and not isGone(self, k) then
            local m = getModel(self, i32(s, p))
            if m then try(m, placementRotation(s, p), f32(s, p + 8), f32(s, p + 12), f32(s, p + 16), 'map') end
          end
        end
      end
    end
  end
  if next(self.movers) then settle(self, now) end
  for _, o in pairs(self.objects) do
    local b = o.box
    if o.move then
      local ox, oy, oz, rx, ry, rz = self:objectPos(o.id, now)
      try(o.model, M.rotation(rx, ry, rz), ox, oy, oz, 'object', o.id)
    elseif b and b[1] <= bx1 and b[4] >= bx0 and b[2] <= by1 and b[5] >= by0 and b[3] <= bz1 and b[6] >= bz0 then
      try(o.model, o.R, o.x, o.y, o.z, 'object', o.id)
    end
  end
  for vid, v in pairs(self.vehicles) do
    local b = v.box
    if vid ~= skipVehicle and v.interior == self.interior and b and b[1] <= bx1 and b[4] >= bx0 and b[2] <= by1
        and b[5] >= by0 and b[3] <= bz1 and b[6] >= bz0 then
      try(v.model, v.R, v.x, v.y, v.z, 'vehicle', vid)
    end
  end
  if not kind then return nil end
  return best / len, kind, id, model
end

function Map:vehicleTouchesPed(v, x, y, z)
  local lo, hi, R = v.model.lo, v.model.hi, v.R
  local cx, cy, cz = (lo[1] + hi[1]) / 2, (lo[2] + hi[2]) / 2, (lo[3] + hi[3]) / 2
  local wx = v.x + R[1] * cx + R[2] * cy + R[3] * cz
  local wy = v.y + R[4] * cx + R[5] * cy + R[6] * cz
  local wz = v.z + R[7] * cx + R[8] * cy + R[9] * cz
  local r = sqrt((hi[1] - lo[1]) ^ 2 + (hi[2] - lo[2]) ^ 2 + (hi[3] - lo[3]) ^ 2) / 2 + M.PED_BOUND_RADIUS
  return (wx - x) ^ 2 + (wy - y) ^ 2 + (wz - z) ^ 2 < r * r
end

function Map:advanceVehicles(now)
  for id, v in pairs(self.vehicles) do
    if (v.svx ~= 0 or v.svy ~= 0 or v.svz ~= 0) and now - v.syncT <= syncWindow(v) + M.PHYSICS_FRAME then
      v.x, v.y, v.z = self:vehiclePredicted(id, now)
      v.movedAt = now
      link(self, v)
    end
  end
end

function Map:placeVehicles(now)
  for id, v in pairs(self.vehicles) do
    if v.svx ~= 0 or v.svy ~= 0 or v.svz ~= 0 then
      local x, y, z = self:vehiclePredicted(id, now)
      if x ~= v.x or y ~= v.y or z ~= v.z then
        v.x, v.y, v.z = x, y, z
        link(self, v)
      end
    end
  end
end

function Map:setVehicleInterior(id, interior)
  local v = self.vehicles[id]
  if v then v.interior = interior end
end

function Map:removeVehicle(id)
  local v = self.vehicles[id]
  if not v then return end
  unlink(self, v)
  releaseModel(self, v.model)
  self.vehicles[id] = nil
end

function Map:setPed(id, x, y, z, speed)
  local p = self.peds[id]
  if not p then
    p = { id = id }
    self.peds[id] = p
  end
  p.x, p.y, p.z = x, y, z
  p.vx, p.vy, p.vz = speed and speed.x or 0, speed and speed.y or 0, speed and speed.z or 0
end

function Map:removePed(id)
  self.peds[id] = nil
end

function Map:clearObjects()
  for id in pairs(self.objects) do self:removeObject(id) end
  for id in pairs(self.vehicles) do self:removeVehicle(id) end
  self.peds = {}
  self.grid, self.big, self.movers = {}, {}, {}
  self.ignored = nil
end

function Map:objectsOver(x, y, now)
  now = now or self.clock()
  if next(self.movers) then settle(self, now) end
  local list = {}
  for id, o in pairs(self.objects) do
    local b = o.box
    if b and x >= b[1] and x <= b[4] and y >= b[2] and y <= b[5] then
      list[#list + 1] = { id = id, model = o.model.id, lo = b[3], hi = b[6] }
    end
  end
  table.sort(list, function(a, b) return a.hi > b.hi end)
  return list
end

function Map:objectIds()
  local n, lo, hi = 0, huge, -huge
  for id in pairs(self.objects) do
    n, lo, hi = n + 1, min(lo, id), max(hi, id)
  end
  return n, lo, hi
end

function Map:reset()
  self:clearObjects()
  self.removals = {}
  self.interior = 0
  self.gen = self.gen + 1
end

function Map:stats()
  local nm, no = 0, 0
  for _ in pairs(self.models) do nm = nm + 1 end
  for _ in pairs(self.objects) do no = no + 1 end
  return { mapBytes = #self.starts + #self.refs + #self.inst + #self.water + #self.modelTable,
           modelBytes = self.modelBytes, models = nm, objects = no, removals = #self.removals }
end

return M
end)()

local phys = {
  GRAVITY = 0.008,
  AIR = 1 / 175,
  PED_Z = 1.0,
  STEP_UP = 1.0,
  BUOYANCY = 1.1 / 125,
  PED_HEIGHT = 1.95,
  SWIM_START = 0.6,
  SWIM_DEPTH = 0.55,
  SWIM_DAMPING = 0.9,
  SWIM_RISE = 0.1,
  SWIM_RISE_CHANGE = 0.02,
  PED_MASS = 70,
  PED_ELASTICITY = 0.05,
  VEHICLE_ELASTICITY = 0.05,
  MOVABLE_MASS_FACTOR = 10,
  ABANDONED_FREE_MASS = 2000,
  ABANDONED_MASS_SCALE = 5000,
  HIT_CAR_SPEED = 0.05,
  HIT_CLOSING_SPEED = 0.1,
  PLAYER_HIT_IMPULSE_CAP = 20,
  HURT_IMPULSE = 10,
  CRUSH_NORMAL_Z = -0.8,
  CRUSH_IMPULSE = 3,
  HURT_SPEED = 0.75,
  FALLEN_SPEED_CHANGE = 0.01,
  FRICTION_SCALE = 150,
  PED_ADHESION = 3.6,
  COLLISION_STEP = 0.3,
  CAR_GROUND_SPEED_CHANGE = 0.01,
  BIKE_GROUND_SPEED_CHANGE = 0.0002,
  BIKE_FAST_SPEED = 0.04,
  AUTOMOBILE = 0,
  BIKE = 9,
}
local DEFAULT_GRAVITY = phys.GRAVITY

local rotor = {
  HUBS = {
    [417] = { 0, 0, 3.89, 6.15 }, [425] = { 0, 0, 1.971, 6.15 }, [447] = { 0, 0, 1.608, 5.15 },
    [465] = { 0, 0, 0.446, 0.72 }, [469] = { 0, 0, 1.608, 5.15 }, [487] = { 0, 0, 2.55, 6.15 },
    [488] = { 0, 0, 2.55, 6.15 }, [497] = { 0, 0, 2.55, 6.15 }, [501] = { 0, 0, 0.446, 0.72 },
    [548] = { -0.024, 0.007, 1.968, 6.15 }, [563] = { 0, 0, 2.077, 6.15 },
  },
  SEMI_THICKNESS = 0.05,
  PUSH = 5,
  MAX_FRAMES = 5,
  EVENT_GAP = 2,
}

local blast = {
  TYPES = {
    [0] = { 'grenade', 9, 300 }, [1] = { 'molotov', 6, 0 }, [2] = { 'rocket', 10, 300 },
    [3] = { 'weak rocket', 10, 200 }, [4] = { 'car', 9, 300 }, [5] = { 'quick car', 9, 300 },
    [6] = { 'boat', 25, 600 }, [7] = { 'aircraft', 25, 600 }, [8] = { 'mine', 10, 150 },
    [9] = { 'object', 10, 150 }, [10] = { 'tank fire', 10, 150 }, [11] = { 'small', 3, 90 },
    [12] = { 'rc vehicle', 3, 90 },
  },
  ROCKET = 2,
  TANK_FIRE = 10,
  MASS_SCALE = 1400,
  FORCE_CAP = 4,
  STANDING_LIFT = 4,
  ROCKETS = { [35] = { speed = 0.4, life = 3 }, [36] = { speed = 0.2, life = 10 } },
  ROCKET_THRUST = 0.008,
  ROCKET_MAX_SPEED = 9.9,
  KEY_FIRE = 4,
  AIM_FRESH = 1,
  TANK_MODEL = 432,
  TANK_RELOAD = 0.8,
  TANK_RANGE = 60,
  TANK_BACKOFF = 0.04,
  TANK_LIFT = math.rad(15),
  TANK_DOWN = math.rad(7),
  TANK_UP = math.rad(35),
  TANK_POS = { 0, -1.394, 2.296 },
  TANK_TARGET = { 0, 2.95, 2.97 },
  GRENADE = 0,
  THROWN = {
    [16] = { name = 'grenade', fuse = 2, elasticity = 0.5, speed = 1 },
    [39] = { name = 'satchel charge', elasticity = 0.03, speed = 0.5 },
  },
  SATCHEL = 39,
  DETONATOR = 40,
  THROW_START = 0.2,
  THROW_FIRE = 8 / 30,
  THROW_HOLD_MAX = 0.533,
  THROW_FORCE = 0.0375 * 1000 / 20,
  THROW_SPEED = 0.22,
  THROW_SPEED_MIN = 0.15,
  THROW_LIFT = 0.4,
  THROW_FORWARD = 0.3,
  THROW_HAND = 0.6,
  SETTLE_SPEED = 0.05,
  SETTLE_ELASTICITY = 0.03,
  THROWN_FRICTION = 0.5,
  THROWN_BACKOFF = 0.02,
  NORMAL_PROBE = 0.05,
  MAX_PROJECTILES = 32,
}

local fight = {
  ANIMS = {
    gas_cwr = { id = 1154, length = 1, keys = { 0, 0.021, -0.004, 0.1, 0.021, -0.064, 0.2, -0.033, -0.107, 0.3, -0.054, -0.135, 0.4, -0.084, -0.227, 0.5, -0.118, -0.331, 0.6, -0.131, -0.372, 0.7, -0.095, -0.432, 0.8, -0.028, -0.539, 0.9, 0.034, -0.642, 1, 0.062, -0.688 } },
    hit_front = { id = 1175, length = 0.6, keys = { 0, 0.063, -0.071, 0.033, 0.122, -0.08, 0.067, 0.129, -0.182, 0.1, 0.103, -0.447, 0.133, 0.062, -0.735, 0.167, 0.023, -0.881, 0.2, -0.047, -1.039, 0.233, -0.14, -1.198, 0.267, -0.203, -1.319, 0.3, -0.229, -1.387, 0.333, -0.24, -1.427, 0.367, -0.236, -1.458, 0.4, -0.217, -1.499, 0.533, -0.217, -1.908, 0.6, -0.217, -2.049 } },
    hit_l = { id = 1177, length = 0.7, keys = { 0, 0, 0, 0.033, 0, 0, 0.067, -0.076, -0.004, 0.1, 0.146, 0.074, 0.2, 0.207, 0.074, 0.333, 0.253, 0.045, 0.433, 0.072, -0.061, 0.567, -0.205, 0.008, 0.7, 0, 0 } },
    hit_back = { id = 1173, length = 0.5, keys = { 0, 0, 0, 0.033, 0, -0.067, 0.067, 0, 0.123, 0.1, 0, 0.305, 0.133, 0, 0.373, 0.167, 0, 0.362, 0.2, 0, 0.32, 0.233, 0, 0.262, 0.267, 0, 0.203, 0.3, 0, 0.171, 0.333, 0, 0.143, 0.367, 0, 0.116, 0.4, 0, 0.103, 0.433, 0, 0.11, 0.467, 0, 0.13, 0.5, 0, 0.15 } },
    hit_r = { id = 1178, length = 0.6, keys = { 0, -0.115, -0.004, 0.033, -0.321, 0.074, 0.133, -0.427, 0.074, 0.267, -0.479, 0.045, 0.367, -0.306, -0.061, 0.5, -0.142, 0.008, 0.6, 0, 0 } },
    hit_behind = { id = 1174, length = 0.667, keys = { 0, 0, 0, 0.033, 0, -0.089, 0.067, -0.034, -0.005, 0.167, -0.134, 0.288, 0.4, -0.097, 0.35, 0.5, -0.146, 0.247, 0.567, -0.166, 0.129, 0.633, 0, 0 } },
    hit_walk = { id = 1179, length = 0.333 },
    dam_arml_frmbk = { id = 1071, length = 0.833 },
    dam_arml_frmft = { id = 1072, length = 0.833 },
    dam_arml_frmlt = { id = 1073, length = 0.667 },
    dam_armr_frmbk = { id = 1074, length = 0.833 },
    dam_armr_frmft = { id = 1075, length = 0.5 },
    dam_armr_frmrt = { id = 1076, length = 0.267 },
    dam_legl_frmbk = { id = 1077, length = 0.833 },
    dam_legl_frmft = { id = 1078, length = 0.833 },
    dam_legl_frmlt = { id = 1079, length = 0.833 },
    dam_legr_frmbk = { id = 1080, length = 0.833 },
    dam_legr_frmft = { id = 1081, length = 0.833 },
    dam_legr_frmrt = { id = 1082, length = 0.833 },
    dam_stomach_frmbk = { id = 1083, length = 0.833 },
    dam_stomach_frmft = { id = 1084, length = 0.833 },
    dam_stomach_frmlt = { id = 1085, length = 0.833 },
    dam_stomach_frmrt = { id = 1086, length = 0.833 },
    hita_1 = { id = 1170, length = 0.3, keys = { 0, 0, 0, 0.033, 0.011, 0.008, 0.067, 0.056, 0.018, 0.1, 0.103, -0.221, 0.133, 0.05, -0.425, 0.167, -0.043, -0.528, 0.2, -0.036, -0.587, 0.233, 0.007, -0.664, 0.267, 0.023, -0.689, 0.3, 0.021, -0.687 } },
    hita_2 = { id = 1171, length = 0.533, keys = { 0, 0.052, 0.004, 0.033, 0.09, -0.113, 0.067, 0.09, -0.266, 0.1, 0.085, -0.425, 0.167, 0.065, -0.73, 0.233, 0.016, -0.957, 0.267, -0.026, -1.14, 0.3, -0.061, -1.303, 0.333, -0.074, -1.438, 0.367, -0.075, -1.562, 0.4, -0.008, -1.787, 0.433, 0.006, -1.79, 0.467, 0.005, -1.795, 0.5, 0.004, -1.802, 0.533, 0.001, -1.807 } },
    hita_3 = { id = 1172, length = 0.567, keys = { 0, 0.002, -2.747, 0.033, 0.037, -2.888, 0.067, 0.076, -3.034, 0.1, 0.114, -3.187, 0.133, 0.149, -3.337, 0.167, 0.126, -3.52, 0.2, 0.091, -3.725, 0.233, 0.052, -3.928, 0.267, 0.018, -4.107, 0.3, -0.005, -4.238, 0.333, -0.016, -4.314, 0.367, -0.019, -4.36, 0.4, -0.018, -4.384, 0.433, -0.014, -4.392, 0.467, -0.008, -4.391, 0.5, -0.001, -4.387, 0.533, 0.004, -4.387, 0.567, 0.008, -4.396 } },
    getup = { id = 1155, length = 1.367, keys = { 0, 0, 0, 0.133, 0.006, 0.016, 0.233, 0.006, 0.016, 0.333, 0.011, 0.021, 0.433, 0.006, 0.016, 0.633, -0.077, -0.066, 0.733, -0.082, -0.015, 0.833, -0.078, 0.065, 0.967, -0.068, 0.171, 1.167, -0.053, 0.128, 1.267, 0.025, -0.054, 1.367, 0, 0 } },
    hitb_1 = { id = 479, length = 0.733, keys = { 0, 0, 0, 0.033, 0, 0, 0.067, 0, 0, 0.1, 0, 0, 0.167, 0, 0, 0.2, 0.057, 0.025, 0.233, 0.093, -0.068, 0.267, 0.123, -0.183, 0.3, 0.146, -0.273, 0.333, 0.163, -0.318, 0.367, 0.171, -0.339, 0.4, 0.15, -0.354, 0.433, 0.069, -0.364, 0.467, -0.04, -0.368, 0.5, -0.104, -0.38, 0.533, -0.11, -0.401, 0.567, -0.1, -0.426, 0.6, -0.077, -0.452, 0.633, -0.05, -0.479, 0.667, -0.021, -0.507, 0.733, 0.021, -0.56 } },
    hitb_2 = { id = 480, length = 0.833, keys = { 0, 0.057, 0.025, 0.033, 0.093, -0.068, 0.067, 0.123, -0.183, 0.1, 0.146, -0.273, 0.133, 0.171, -0.339, 0.167, 0.15, -0.354, 0.267, -0.077, -0.297, 0.3, -0.055, -0.408, 0.333, 0, -0.52, 0.367, 0.021, -0.533, 0.4, 0.037, -0.517, 0.433, 0.05, -0.509, 0.467, 0.06, -0.528, 0.5, 0.066, -0.557, 0.533, 0.072, -0.579, 0.567, 0.079, -0.594, 0.6, 0.088, -0.607, 0.633, 0.096, -0.619, 0.667, 0.099, -0.626, 0.7, 0.095, -0.626, 0.733, 0.079, -0.616, 0.767, 0.054, -0.597, 0.8, 0.024, -0.572, 0.833, -0.002, -0.551 } },
    hitb_3 = { id = 481, length = 1.433, keys = { 0, 0, 0.039, 0.033, 0.063, -0.032, 0.067, 0.122, -0.04, 0.1, 0.129, -0.142, 0.133, 0.103, -0.407, 0.167, 0.062, -0.696, 0.2, 0.023, -0.841, 0.233, -0.047, -0.999, 0.267, -0.14, -1.158, 0.3, -0.203, -1.279, 0.333, -0.229, -1.347, 0.367, -0.24, -1.387, 0.4, -0.236, -1.418, 0.433, -0.217, -1.46, 0.467, -0.131, -1.519, 0.5, -0.049, -1.6, 0.533, -0.024, -1.806, 0.567, -0.014, -2.018, 0.6, -0.012, -2.234, 0.633, -0.013, -2.404, 0.667, -0.013, -2.557, 0.7, -0.011, -2.662, 0.733, -0.009, -2.774, 0.767, -0.009, -2.89, 0.8, -0.01, -3.063, 0.833, -0.01, -3.111, 0.867, -0.01, -3.152, 0.9, -0.01, -3.188, 0.933, -0.01, -3.219, 0.967, -0.011, -3.247, 1, -0.011, -3.272, 1.033, -0.011, -3.298, 1.067, -0.012, -3.323, 1.1, -0.012, -3.35, 1.133, -0.012, -3.379, 1.167, -0.012, -3.407, 1.2, -0.012, -3.434, 1.233, -0.012, -3.459, 1.267, -0.012, -3.459, 1.3, -0.012, -3.459, 1.333, -0.012, -3.459, 1.367, -0.012, -3.459, 1.4, -0.012, -3.459, 1.433, -0.012, -3.459 } },
    hitc_1 = { id = 491, length = 0.3, keys = { 0, 0.252, 0.09, 0.1, -0.021, -0.176, 0.2, 0, -0.144, 0.3, 0, -0.19 } },
    hitc_2 = { id = 492, length = 0.667, keys = { 0, 0, 0, 0.033, 0, 0, 0.067, 0.057, 0.025, 0.1, 0.093, -0.068, 0.133, 0.123, -0.183, 0.233, 0.163, -0.497, 0.433, -0.11, -0.807, 0.467, -0.113, -0.85, 0.5, -0.103, -0.89, 0.533, -0.082, -0.927, 0.567, -0.057, -0.964, 0.667, 0.021, -1.073 } },
    hitc_3 = { id = 493, length = 0.833, keys = { 0, 0, 0, 0.1, -0.13, -0.184, 0.2, -0.115, -0.409, 0.433, -0.018, -0.958, 0.5, 0.001, -1.127, 0.6, 0.003, -1.244, 0.7, 0.001, -1.345, 0.767, 0.001, -1.427 } },
    hitd_1 = { id = 501, length = 0.667, keys = { 0, 0, -0.071, 0.033, 0, -0.107, 0.067, 0, -0.142, 0.1, 0, -0.179, 0.133, 0.002, -0.25, 0.167, 0.004, -0.326, 0.2, 0.008, -0.399, 0.233, 0.02, -0.449, 0.267, 0.031, -0.501, 0.3, 0.042, -0.55, 0.333, 0.048, -0.596, 0.367, 0.047, -0.628, 0.4, 0.031, -0.645, 0.433, 0.001, -0.651, 0.467, -0.029, -0.643, 0.5, -0.047, -0.644, 0.533, -0.044, -0.64, 0.567, -0.03, -0.632, 0.6, -0.013, -0.624, 0.633, 0, -0.617, 0.667, 0.001, -0.616 } },
    hitd_2 = { id = 502, length = 1.833, keys = { 0, 0, 0, 0.067, -0.002, 0, 0.1, -0.001, 0.005, 0.133, -0.003, 0.007, 0.167, -0.005, 0.005, 0.2, -0.006, 0.003, 0.233, -0.008, -0.001, 0.267, -0.01, -0.007, 0.3, -0.011, 0.002, 0.333, -0.013, 0.014, 0.367, -0.014, 0.023, 0.4, -0.013, 0.021, 0.433, -0.011, 0.07, 0.467, -0.01, 0.028, 0.5, -0.01, -0.017, 0.533, -0.01, -0.065, 0.567, -0.01, -0.116, 0.6, -0.01, -0.168, 0.633, -0.01, -0.222, 0.667, -0.01, -0.273, 0.7, -0.01, -0.325, 0.733, -0.01, -0.374, 0.767, -0.01, -0.42, 0.8, -0.01, -0.462, 0.833, -0.01, -0.5, 0.867, -0.01, -0.532, 0.9, -0.01, -0.551, 1.033, -0.01, -0.522, 1.067, -0.01, -0.515, 1.1, -0.01, -0.518, 1.133, -0.01, -0.536, 1.167, -0.01, -0.569, 1.2, -0.01, -0.611, 1.233, -0.01, -0.661, 1.267, -0.01, -0.717, 1.3, -0.01, -0.775, 1.333, -0.01, -0.836, 1.367, -0.01, -0.896, 1.4, -0.01, -0.956, 1.433, -0.01, -1.013, 1.467, -0.01, -1.068, 1.5, -0.01, -1.128, 1.533, -0.01, -1.189, 1.7, -0.01, -1.454, 1.833, -0.01, -1.454 } },
    hitd_3 = { id = 503, length = 0.967, keys = { 0, 0, -0.012, 0.033, 0.18, -0.151, 0.133, 0.153, -0.545, 0.233, 0.087, -0.935, 0.267, 0.064, -1.05, 0.3, 0.043, -1.152, 0.333, 0.026, -1.24, 0.367, 0.012, -1.31, 0.4, 0, -1.364, 0.433, -0.013, -1.406, 0.467, -0.025, -1.438, 0.5, -0.037, -1.465, 0.533, -0.049, -1.487, 0.567, -0.061, -1.511, 0.6, -0.072, -1.537, 0.633, -0.084, -1.569, 0.667, -0.084, -1.569, 0.7, -0.084, -1.569, 0.733, -0.084, -1.569, 0.767, -0.084, -1.569, 0.8, -0.084, -1.569, 0.833, -0.084, -1.569, 0.867, -0.084, -1.569, 0.9, -0.084, -1.569, 0.933, -0.084, -1.569, 0.967, -0.084, -1.569 } },
    bat_hit_1 = { id = 22, length = 0.833, keys = { 0, 0, 0, 0.1, 0.003, -0.229, 0.367, 0.003, -0.637, 0.6, -0.039, -0.843, 0.7, -0.001, -1.051, 0.833, -0.001, -1.051 } },
    bat_hit_2 = { id = 23, length = 1.067, keys = { 0, 0.064, 0.101, 0.033, 0.069, 0.116, 0.067, 0.027, 0.078, 0.1, -0.033, 0.022, 0.133, -0.084, -0.049, 0.167, -0.093, -0.137, 0.2, -0.063, -0.238, 0.233, -0.022, -0.347, 0.267, 0.026, -0.46, 0.3, 0.082, -0.576, 0.333, 0.141, -0.694, 0.367, 0.2, -0.812, 0.4, 0.258, -0.928, 0.433, 0.31, -1.038, 0.467, 0.354, -1.144, 0.5, 0.389, -1.241, 0.533, 0.408, -1.326, 0.567, 0.412, -1.4, 0.6, 0.405, -1.464, 0.633, 0.392, -1.52, 0.667, 0.375, -1.57, 0.7, 0.36, -1.619, 0.733, 0.348, -1.666, 0.767, 0.334, -1.711, 0.8, 0.318, -1.752, 0.833, 0.3, -1.789, 0.867, 0.279, -1.82, 0.9, 0.254, -1.845, 0.933, 0.224, -1.861, 0.967, 0.182, -1.855, 1, 0.126, -1.825, 1.033, 0.064, -1.786, 1.067, 0.006, -1.751 } },
    bat_hit_3 = { id = 24, length = 1.133, keys = { 0, -0.131, -0.088, 0.033, -0.049, -0.17, 0.067, -0.034, -0.271, 0.1, -0.024, -0.375, 0.133, -0.018, -0.481, 0.167, -0.014, -0.588, 0.2, -0.012, -0.695, 0.233, -0.012, -0.804, 0.267, -0.012, -0.912, 0.3, -0.013, -1.021, 0.333, -0.013, -1.127, 0.367, -0.011, -1.232, 0.4, -0.009, -1.344, 0.433, -0.009, -1.46, 0.467, -0.009, -1.562, 0.5, -0.01, -1.634, 0.533, -0.01, -1.681, 0.567, -0.01, -1.722, 0.6, -0.01, -1.758, 0.633, -0.01, -1.789, 0.667, -0.011, -1.816, 0.7, -0.011, -1.843, 0.733, -0.011, -1.868, 0.767, -0.012, -1.894, 0.8, -0.012, -1.92, 0.833, -0.012, -1.948, 0.867, -0.012, -1.977, 0.9, -0.012, -2.003, 0.933, -0.012, -2.029, 0.967, -0.012, -2.029, 1, -0.012, -2.029, 1.033, -0.012, -2.029, 1.067, -0.012, -2.029, 1.1, -0.012, -2.029, 1.133, -0.012, -2.029 } },
    knife_hit_1 = { id = 755, length = 0.567, keys = { 0, 0, 0, 0.2, 0.152, -0.803, 0.4, 0.122, -1.647, 0.567, 0.015, -1.742 } },
    knife_hit_2 = { id = 756, length = 0.633, keys = { 0, 0.047, -0.029, 0.033, 0.074, -0.033, 0.067, 0.097, -0.051, 0.1, 0.105, -0.181, 0.133, 0.091, -0.416, 0.167, 0.07, -0.563, 0.2, 0.049, -0.712, 0.233, 0.026, -0.855, 0.267, 0.006, -0.988, 0.3, -0.009, -1.103, 0.333, -0.02, -1.193, 0.367, -0.023, -1.263, 0.4, -0.024, -1.319, 0.433, -0.022, -1.364, 0.467, -0.02, -1.401, 0.633, 0, -1.571 } },
    knife_hit_3 = { id = 757, length = 1.6, keys = { 0, 0, -0.001, 0.067, 0.175, -0.124, 0.167, 0.11, -0.387, 0.3, 0.041, -0.688, 0.433, 0.063, -1, 0.733, -0.006, -1.122, 0.767, -0.013, -1.136, 0.8, -0.018, -1.154, 0.833, -0.021, -1.178, 0.867, -0.021, -1.205, 0.9, -0.021, -1.236, 0.933, -0.021, -1.27, 0.967, -0.019, -1.304, 1, -0.018, -1.338, 1.033, -0.016, -1.372, 1.067, -0.015, -1.404, 1.1, -0.015, -1.404, 1.133, -0.015, -1.404, 1.167, -0.015, -1.404, 1.2, -0.015, -1.404, 1.233, -0.015, -1.404, 1.267, -0.015, -1.404, 1.3, -0.015, -1.404, 1.333, -0.015, -1.404, 1.367, -0.015, -1.404, 1.4, -0.015, -1.404, 1.433, -0.015, -1.404, 1.467, -0.015, -1.404, 1.5, -0.015, -1.404, 1.533, -0.015, -1.404, 1.567, -0.015, -1.404, 1.6, -0.015, -1.404 } },
    sword_hit_1 = { id = 1550, length = 0.833, keys = { 0, 0, 0, 0.133, 0.098, -0.033, 0.233, 0.102, -0.252, 0.333, 0.091, -0.479, 0.433, 0.091, -0.519, 0.5, 0.102, -0.711, 0.6, 0.072, -0.916, 0.7, 0.038, -1.111, 0.833, -0.006, -1.355 } },
    sword_hit_2 = { id = 1551, length = 1.033, keys = { 0, 0.037, 0.086, 0.033, 0.064, 0.141, 0.067, 0.069, 0.156, 0.1, 0.027, 0.118, 0.133, -0.033, 0.062, 0.167, -0.084, -0.009, 0.2, -0.093, -0.097, 0.233, -0.063, -0.198, 0.267, -0.022, -0.307, 0.3, 0.026, -0.42, 0.333, 0.082, -0.536, 0.367, 0.141, -0.654, 0.4, 0.2, -0.772, 0.433, 0.258, -0.888, 0.467, 0.31, -0.998, 0.5, 0.354, -1.104, 0.533, 0.389, -1.201, 0.567, 0.408, -1.286, 0.6, 0.412, -1.36, 0.633, 0.405, -1.424, 0.667, 0.392, -1.479, 0.7, 0.375, -1.53, 0.733, 0.36, -1.579, 0.767, 0.348, -1.626, 0.8, 0.334, -1.671, 0.833, 0.318, -1.712, 0.867, 0.3, -1.749, 0.9, 0.279, -1.78, 0.933, 0.254, -1.805, 1.033, 0.006, -1.711 } },
    sword_hit_3 = { id = 1552, length = 0.867, keys = { 0, -0.131, -0.088, 0.033, -0.049, -0.17, 0.067, -0.024, -0.375, 0.1, -0.018, -0.481, 0.167, -0.012, -0.804, 0.233, -0.011, -1.232, 0.267, -0.009, -1.344, 0.3, -0.009, -1.562, 0.333, -0.01, -1.634, 0.367, -0.01, -1.681, 0.4, -0.01, -1.722, 0.433, -0.01, -1.758, 0.467, -0.01, -1.789, 0.5, -0.011, -1.816, 0.533, -0.011, -1.843, 0.567, -0.011, -1.868, 0.6, -0.012, -1.894, 0.633, -0.012, -1.92, 0.667, -0.012, -1.948, 0.7, -0.012, -1.977, 0.733, -0.012, -2.003, 0.767, -0.012, -2.029, 0.8, -0.012, -2.029, 0.833, -0.012, -2.029, 0.867, -0.012, -2.029 } },
    csaw_hit_1 = { id = 316, length = 0.833, keys = { 0, 0, 0, 0.1, 0.003, -0.229, 0.367, 0.003, -0.637, 0.6, -0.039, -0.843, 0.7, -0.001, -1.051, 0.833, -0.001, -1.051 } },
    csaw_hit_2 = { id = 317, length = 1.067, keys = { 0, 0.064, 0.101, 0.033, 0.069, 0.116, 0.067, 0.027, 0.078, 0.1, -0.033, 0.022, 0.133, -0.084, -0.049, 0.167, -0.093, -0.137, 0.2, -0.063, -0.238, 0.233, -0.022, -0.347, 0.267, 0.026, -0.46, 0.3, 0.082, -0.576, 0.333, 0.141, -0.694, 0.367, 0.2, -0.812, 0.4, 0.258, -0.928, 0.433, 0.31, -1.038, 0.467, 0.354, -1.144, 0.5, 0.389, -1.241, 0.533, 0.408, -1.326, 0.567, 0.412, -1.4, 0.6, 0.405, -1.464, 0.633, 0.392, -1.52, 0.667, 0.375, -1.57, 0.7, 0.36, -1.619, 0.733, 0.348, -1.666, 0.767, 0.334, -1.711, 0.8, 0.318, -1.752, 0.833, 0.3, -1.789, 0.867, 0.279, -1.82, 0.9, 0.254, -1.845, 0.933, 0.224, -1.861, 0.967, 0.182, -1.855, 1, 0.126, -1.825, 1.033, 0.064, -1.786, 1.067, 0.006, -1.751 } },
    csaw_hit_3 = { id = 318, length = 1.133, keys = { 0, -0.131, -0.088, 0.033, -0.049, -0.17, 0.067, -0.034, -0.271, 0.1, -0.024, -0.375, 0.133, -0.018, -0.481, 0.167, -0.014, -0.588, 0.2, -0.012, -0.695, 0.233, -0.012, -0.804, 0.267, -0.012, -0.912, 0.3, -0.013, -1.021, 0.333, -0.013, -1.127, 0.367, -0.011, -1.232, 0.4, -0.009, -1.344, 0.433, -0.009, -1.46, 0.467, -0.009, -1.562, 0.5, -0.01, -1.634, 0.533, -0.01, -1.681, 0.567, -0.01, -1.722, 0.6, -0.01, -1.758, 0.633, -0.01, -1.789, 0.667, -0.011, -1.816, 0.7, -0.011, -1.843, 0.733, -0.011, -1.868, 0.767, -0.012, -1.894, 0.8, -0.012, -1.92, 0.833, -0.012, -1.948, 0.867, -0.012, -1.977, 0.9, -0.012, -2.003, 0.933, -0.012, -2.029, 0.967, -0.012, -2.029, 1, -0.012, -2.029, 1.033, -0.012, -2.029, 1.067, -0.012, -2.029, 1.1, -0.012, -2.029, 1.133, -0.012, -2.029 } },
    dildo_hit_1 = { id = 428, length = 0.767, keys = { 0, 0, 0, 0.1, 0.003, -0.229, 0.367, 0.003, -0.637, 0.6, -0.039, -0.843, 0.7, -0.001, -1.051, 0.767, -0.001, -1.051 } },
    dildo_hit_2 = { id = 429, length = 1.033, keys = { 0, 0.064, 0.121, 0.033, 0.069, 0.137, 0.067, 0.027, 0.098, 0.1, -0.033, 0.042, 0.133, -0.084, -0.028, 0.167, -0.093, -0.117, 0.2, -0.063, -0.218, 0.233, -0.022, -0.326, 0.267, 0.026, -0.439, 0.3, 0.082, -0.557, 0.333, 0.141, -0.675, 0.367, 0.2, -0.792, 0.4, 0.258, -0.907, 0.433, 0.31, -1.019, 0.467, 0.354, -1.123, 0.5, 0.389, -1.221, 0.533, 0.408, -1.307, 0.567, 0.412, -1.38, 0.6, 0.405, -1.443, 0.633, 0.392, -1.5, 0.667, 0.375, -1.551, 0.7, 0.36, -1.599, 0.733, 0.348, -1.646, 0.767, 0.334, -1.69, 0.8, 0.318, -1.732, 0.833, 0.3, -1.769, 0.867, 0.279, -1.8, 0.9, 0.254, -1.824, 0.933, 0.224, -1.841, 0.967, 0.182, -1.836, 1, 0.064, -1.766, 1.033, 0.006, -1.73 } },
    dildo_hit_3 = { id = 430, length = 0.9, keys = { 0, -0.001, -0.084, 0.033, -0.005, -0.175, 0.067, -0.008, -0.271, 0.1, -0.008, -0.37, 0.133, -0.008, -0.471, 0.167, -0.008, -0.57, 0.2, -0.009, -0.667, 0.267, -0.01, -0.877, 0.3, -0.01, -0.973, 0.333, -0.01, -1.041, 0.367, -0.01, -1.087, 0.4, -0.01, -1.127, 0.433, -0.011, -1.161, 0.467, -0.011, -1.191, 0.5, -0.011, -1.218, 0.533, -0.011, -1.242, 0.567, -0.012, -1.264, 0.6, -0.012, -1.285, 0.633, -0.012, -1.307, 0.667, -0.012, -1.315, 0.7, -0.012, -1.309, 0.733, -0.012, -1.302, 0.767, -0.012, -1.302, 0.8, -0.012, -1.302, 0.833, -0.012, -1.302, 0.867, -0.012, -1.302, 0.9, -0.012, -1.302 } },
    flower_hit = { id = 535, length = 0.833 },
    hit_fightkick = { id = 506, length = 0.5, keys = { 0, 0, -0.017, 0.033, 0.035, -0.157, 0.067, 0.074, -0.304, 0.1, 0.112, -0.456, 0.133, 0.147, -0.606, 0.167, 0.122, -0.716, 0.2, 0.092, -0.822, 0.233, 0.057, -0.926, 0.267, 0.022, -1.026, 0.3, -0.007, -1.127, 0.333, -0.018, -1.203, 0.367, -0.021, -1.251, 0.4, -0.02, -1.274, 0.433, -0.011, -1.28, 0.467, 0, -1.286, 0.5, 0.006, -1.287 } },
    hit_fightkick_b = { id = 507, length = 1.133, keys = { 0, 0.008, 0, 0.067, 0.008, -0.32, 0.167, 0.008, -0.713, 0.267, 0.007, -0.864, 0.333, 0.007, -0.931, 0.467, 0.007, -1.049, 0.567, 0.007, -1.137, 0.733, 0.007, -1.137 } },
  },
  FRAME = 1 / 30,
  FORWARD = 0.7,
  LEVELS = { H = 0.5, L = 0, G = -1, HL = 0.5, LL = 0, GL = -1 },
  GROUND = 4,
  MOVING = 5,
  COMBO_FALL = 0x10,
  HEAVY_HIT = 20,
  COMBOS = {
    unarmed1 = { hit = { 5, 8, 10, 10.5, 7 }, radius = { 0.4, 0.4, 0.4, 0.4, 0.4 }, level = { 'H', 'H', 'H', 'G', 'HL' },
                 damage = { 6, 9, 15, 25, 5 }, flags = 0x60f, hits = { 'hita_1', 'hita_2', 'hita_3' } },
    unarmed2 = { hit = { 6, 8, 11, 12, 4 }, radius = { 0.4, 0.4, 0.4, 0.4, 0.35 }, level = { 'L', 'H', 'H', 'G', 'HL' },
                 damage = { 10, 7, 16, 25, 5 }, flags = 0x64f, hits = { 'hitb_1', 'hitb_2', 'hitb_3' } },
    unarmed3 = { hit = { 9, 13, 15, 8, 7 }, radius = { 0.4, 0.4, 0.4, 0.4, 0.4 }, level = { 'H', 'H', 'H', 'G', 'HL' },
                 damage = { 6, 9, 15, 25, 5 }, flags = 0x64f, hits = { 'hitc_1', 'hitc_2', 'hitc_3' } },
    unarmed4 = { hit = { 13, 6, 9, 11, 9 }, radius = { 0.4, 0.5, 0.4, 0.4, 0.4 }, level = { 'L', 'HL', 'L', 'G', 'HL' },
                 damage = { 12, 15, 200, 25, 5 }, flags = 0x264f, hits = { 'hitd_1', 'hitd_2', 'hitd_3' } },
    bat = { hit = { 11, 14, 13, 18, 11 }, radius = { 0.5, 0.5, 0.5, 0.4, 0.5 }, level = { 'L', 'L', 'L', 'GL', 'LL' },
            damage = { 18, 18, 25, 25, 10 }, flags = 0x64f, hits = { 'bat_hit_1', 'bat_hit_2', 'bat_hit_3' } },
    knife = { hit = { 8, 9, 10, 11, 6 }, radius = { 0.4, 0.4, 0.4, 0.4, 0.4 }, level = { 'H', 'H', 'H', 'G', 'HL' },
              damage = { 10, 10, 25, 25, 10 }, flags = 0x64f, hits = { 'knife_hit_1', 'knife_hit_2', 'knife_hit_3' } },
    sword = { hit = { 11, 15, 12, 18, 8 }, radius = { 0.5, 0.5, 0.5, 0.4, 0.5 }, level = { 'H', 'H', 'H', 'G', 'HL' },
              damage = { 10, 15, 25, 25, 10 }, flags = 0x64f, hits = { 'sword_hit_1', 'sword_hit_2', 'sword_hit_3' } },
    chainsaw = { hit = { 14, 14, 13, 10, 1 }, radius = { 0.5, 0.5, 0.5, 0.4, 0.4 }, level = { 'LL', 'LL', 'LL', 'G', 'LL' },
                 damage = { 50, 60, 100, 25, 25 }, flags = 0x44f, hits = { 'csaw_hit_1', 'csaw_hit_2', 'csaw_hit_3' } },
    dildo = { hit = { 11, 15, 13, 18, 11 }, radius = { 0.5, 0.5, 0.5, 0.5, 0.5 }, level = { 'L', 'L', 'L', 'G', 'LL' },
              damage = { 18, 18, 25, 25, 10 }, flags = 0x607, hits = { 'dildo_hit_1', 'dildo_hit_2', 'dildo_hit_3' } },
    flowers = { hit = { 6, 15, 13, 18, 11 }, radius = { 0.5, 0.5, 0.5, 0.5, 0.5 }, level = { 'H', 'L', 'L', 'G', 'HL' },
                damage = { 18, 18, 25, 25, 10 }, flags = 0, hits = { 'flower_hit', 'flower_hit', 'flower_hit' } },
    kick = { hit = { 6, 10 }, radius = { 0.5, 0.5 }, level = { 'L', 'HL' }, damage = { 8, 20 }, flags = 0x021,
             hits = { 'hit_fightkick', 'hit_fightkick_b' } },
    whip = { hit = { 7 }, radius = { 0.5 }, level = { 'L' }, damage = { 10 }, flags = 0, hits = { 'hita_2' } },
  },
  ATTACKS = {
    [1136] = { 'unarmed1', 1 }, [1137] = { 'unarmed1', 2 }, [1138] = { 'unarmed1', 3 }, [1140] = { 'unarmed1', 4 },
    [1141] = { 'unarmed1', 5 },
    [472] = { 'unarmed2', 1 }, [473] = { 'unarmed2', 2 }, [474] = { 'unarmed2', 3 }, [476] = { 'unarmed2', 4 },
    [478] = { 'unarmed2', 5 },
    [482] = { 'unarmed3', 1 }, [483] = { 'unarmed3', 2 }, [484] = { 'unarmed3', 3 }, [487] = { 'unarmed3', 4 },
    [489] = { 'unarmed3', 5 },
    [494] = { 'unarmed4', 1 }, [495] = { 'unarmed4', 2 }, [496] = { 'unarmed4', 3 }, [498] = { 'unarmed4', 4 },
    [500] = { 'unarmed4', 5 },
    [17] = { 'bat', 1 }, [18] = { 'bat', 2 }, [19] = { 'bat', 3 }, [20] = { 'bat', 4 }, [27] = { 'bat', 5 },
    [749] = { 'knife', 1 }, [750] = { 'knife', 2 }, [751] = { 'knife', 3 }, [754] = { 'knife', 4 }, [759] = { 'knife', 5 },
    [1545] = { 'sword', 1 }, [1546] = { 'sword', 2 }, [1547] = { 'sword', 3 }, [1548] = { 'sword', 4 },
    [1554] = { 'sword', 5 },
    [312] = { 'chainsaw', 1 }, [313] = { 'chainsaw', 2 }, [314] = { 'chainsaw', 3 }, [315] = { 'chainsaw', 4 },
    [319] = { 'chainsaw', 5 },
    [423] = { 'dildo', 1 }, [424] = { 'dildo', 2 }, [425] = { 'dildo', 3 }, [427] = { 'dildo', 4 },
    [533] = { 'flowers', 1 },
    [504] = { 'kick', 1 }, [505] = { 'kick', 2 },
    [1165] = { 'whip', 1 },
  },
  DIRECTION_HITS = { [0] = 'hit_front', 'hit_l', 'hit_behind', 'hit_r' },
  BULLET_TARGET_PLAYER = 1,
  HEAVY_BULLETS = { [24] = true, [25] = true, [26] = true, [27] = true, [33] = true },
  BULLET_HIT_DELAY = 2.5,
  HEAD_Z = 0.5,
  LEG_Z = -0.15,
  ARM_SIDE = 0.2,
  STANDING_SPEED = 0.01,
  MOVED_RECENTLY = 0.25,
  EXTRACTS_VELOCITY = { hit_front = true, hit_back = true },
  PIECE_HITS = {
    head = { [0] = 'hit_front', 'hit_l', 'hit_back', 'hit_r' },
    torso = { [0] = 'dam_stomach_frmft', 'dam_stomach_frmlt', 'dam_stomach_frmbk', 'dam_stomach_frmrt' },
    left_arm = { [0] = 'dam_arml_frmft', 'dam_arml_frmlt', 'dam_arml_frmbk', 'dam_arml_frmft' },
    right_arm = { [0] = 'dam_armr_frmft', 'dam_armr_frmft', 'dam_armr_frmbk', 'dam_armr_frmrt' },
    left_leg = { [0] = 'dam_legl_frmft', 'dam_legl_frmlt', 'dam_legl_frmbk', 'dam_legl_frmft' },
    right_leg = { [0] = 'dam_legr_frmft', 'dam_legr_frmft', 'dam_legr_frmbk', 'dam_legr_frmrt' },
  },
  PIECE_VARIANTS = {
    torso = { 'dam_stomach_frmbk', 'dam_stomach_frmft', 'dam_stomach_frmlt', 'dam_stomach_frmrt' },
    left_arm = { 'dam_arml_frmbk', 'dam_arml_frmft', 'dam_arml_frmlt' },
    right_arm = { 'dam_armr_frmbk', 'dam_armr_frmft', 'dam_armr_frmrt' },
    left_leg = { 'dam_legl_frmbk', 'dam_legl_frmft', 'dam_legl_frmlt' },
    right_leg = { 'dam_legr_frmbk', 'dam_legr_frmft', 'dam_legr_frmrt' },
  },
  SPRAYS = { [41] = { name = 'spraycan', speed = 0.05 }, [42] = { name = 'extinguisher', speed = 0.1 } },
  SPRAY_LIFE = 1,
  SPRAY_RANGE = 1,
  SPRAY_HAND = 0.3,
  SPRAY_FORWARD = 0.3,
  SPRAY_FRESH = 0.5,
  CHOKE_MIN = 1,
  CHOKE_MAX = 2,
  CHOKE_SPEED_MIN = 0.75,
  CHOKE_SPEED_MAX = 1,
}

local surf = {
  LINE_FROM = 0.25,
  LINE_TO = 1.75,
  HOLD = 2,
  TRAIN_MODELS = { [569] = true, [570] = true },
}

local logFile = (function()
  if not CFG.logFile then return nil end
  local f = io.open(here .. CFG.logFile, 'wb')
  if f then
    f:write(('=== %s\n'):format(os.date('%Y-%m-%d %H:%M:%S')))
    f:flush()
  end
  return f
end)()

local function emit(line)
  print(line)
  if logFile then
    logFile:write(os.date('[%H:%M:%S] '), line, '\n')
    logFile:flush()
  end
end

local function event(fmt, ...)
  emit(('[slapfix] EVENT: ' .. fmt):format(...))
end

local function log(fmt, ...)
  if CFG.log then emit(('[slapfix] ' .. fmt):format(...)) end
end

local now = os.clock
local t0 = now()

local function dbg(fmt, ...)
  if CFG.debug then emit(('[slapfix %.3f] ' .. fmt):format(now() - t0, ...)) end
end

local reported = {}

local function problem(key, fmt, ...)
  if reported[key] then return end
  reported[key] = true
  emit(('[slapfix %.3f] PROBLEM: ' .. fmt):format(now() - t0, ...))
end

local map, err = colmap.open(here .. CFG.map, { clock = now })
if not map then
  log('no collision map (%s): falls end at the height the bot had before', tostring(err))
end
local st = { frozen = false, pending = nil,
             created = 0, noCollision = 0, destroyed = 0, removed = 0,
             onfootRate = 30,
             lastSync = -math.huge }

local function held()
  return CFG.respectFreeze and st.frozen
end

local DROP_MIN = 1.0
local REST_GAP = 0.05
local DROP_TICK = 0.09
local DROP_FIRST = -0.1
local DROP_STEP = -0.8
local DROP_SPEED_DIV = 5
local WALK_STEP = 0.2
local WALK_DIST = 1
local WALK_SPEED_Z = 0.05
local PHYSICS_FRAME = colmap.PHYSICS_FRAME
local SHIFT_FRAMES = math.floor(DROP_TICK / PHYSICS_FRAME + 0.5)
local STAND_LINE_REACH = 0.15
local STAND_LINE_FROM = 0.25
local RIDE_JUMP_LOG = 0.5
local RESTING = 0.01
local MAP_Z_LOW_LIMIT = -100
local PATH_LOAD_RADIUS = 350
local FALLEN_NODE_RAISE = 2
local FALLEN_NO_NODE_Z = -95

local function describe(g, w, what, model, int, objectId)
  local s = g and ('%s %.2f model %d'):format(what, g, model) or 'no ground'
  if int then s = s .. (' interior %d'):format(int) end
  if objectId then s = s .. (' object %d'):format(objectId) end
  if w then s = s .. (', water %.2f'):format(w) end
  return s
end

local function groundUnder(x, y, z)
  if not map then return nil, 'no map' end
  local g, w, what, model, int, objectId = map:probe(x, y, z - phys.PED_Z + phys.STEP_UP)
  local top = g and g + phys.PED_Z
  return top, describe(g, w, what, model, int, objectId), what, objectId
end

local function sendAt(x, y, z, speedZ)
  setBotPosition(x, y, z)
  st.speedZ = speedZ
  updateSync()
  st.speedZ = nil
end

local function describeHit(h)
  return h and ('%s model %d%s, %.2f m deep, normal %.2f %.2f %.2f'):format(h.kind, h.model,
    h.id and (' id %d'):format(h.id) or '', h.depth, h.nx, h.ny, h.nz)
end

local function standLine(x, y, z, standing, ceiling)
  local g, _, what, id = groundUnder(x, y, standing and z - STAND_LINE_FROM or z)
  if not g or g < z - (standing and STAND_LINE_REACH or 0) then return z, false end
  if ceiling and g > z then return z, true, what, id end
  return g, true, what, id
end

local function moveBody(x, y, z, dx, dy, dz, standing, frames, stopOnStand)
  local last, what, id
  frames = frames or SHIFT_FRAMES
  dx, dy, dz = dx / frames, dy / frames, dz / frames
  for _ = 1, frames do
    x, y, z = x + dx, y + dy, z + dz
    local ceiling
    if map then ceiling = select(9, map:pedContacts(x, y, z, now(), standing, dx, dy)) end
    local was = standing
    z, standing, what, id = standLine(x, y, z, standing, ceiling)
    if map then
      local nx, ny, nz, hit = map:shiftPed(x, y, z, now(), standing, dx, dy)
      if hit then x, y, z, last = nx, ny, nz, hit end
    end
    if stopOnStand and standing and not was then break end
    if not stopOnStand and not standing then break end
  end
  return x, y, z, describeHit(last), standing, what, id
end

local function pushOut(x, y, z)
  local last
  if not map then return x, y, z end
  for _ = 1, SHIFT_FRAMES do
    local nx, ny, nz, hit = map:shiftPed(x, y, z, now(), false)
    if not hit then break end
    x, y, z, last = nx, ny, nz, hit
  end
  return x, y, z, describeHit(last)
end

local NEARBY_RADIUS = 20
local NEARBY_OBJECTS = 5

local function surroundings(x, y, z)
  if not CFG.debug or not map then return end
  local groups, objects, total = map:nearby(x, y, z, NEARBY_RADIUS, now())
  local parts = {}
  for _, g in ipairs(groups) do
    parts[#parts + 1] = ('int %d: %d (z %.1f..%.1f%s)%s'):format(g.interior, g.count, g.zmin, g.zmax,
      g.removed > 0 and (', %d removed'):format(g.removed) or '',
      (g.interior == map.interior or g.interior == 13) and ' solid' or '')
  end
  dbg('map within %d m: %s', NEARBY_RADIUS, #parts > 0 and table.concat(parts, '; ') or 'nothing')
  local list = {}
  for i = 1, math.min(#objects, NEARBY_OBJECTS) do
    local o = objects[i]
    list[#list + 1] = ('%s %d model %d %.1f m z %.1f top %s%s'):format(o.kind, o.id, o.model, o.dist, o.z,
      o.top and ('%.1f'):format(o.top) or '-',
      o.interior and o.interior ~= map.interior and (' interior %d'):format(o.interior) or '')
  end
  dbg('objects: %d held, %d bodies within %d m%s; since the last SetPlayerPos %d created, %d without collision, %d destroyed, %d buildings removed',
    total, #objects, NEARBY_RADIUS, #list > 0 and (': ' .. table.concat(list, ', ')) or '',
    st.created, st.noCollision, st.destroyed, st.removed)
end

local startBody
local animFrame
local swimFrame

local function toVehicle(v, x, y, z)
  local R, dx, dy, dz = v.R, x - v.x, y - v.y, z - v.z
  return R[1] * dx + R[4] * dy + R[7] * dz, R[2] * dx + R[5] * dy + R[8] * dz, R[3] * dx + R[6] * dy + R[9] * dz
end

local function fromVehicle(v, a)
  local R = v.R
  return v.x + R[1] * a.lx + R[2] * a.ly + R[3] * a.lz, v.y + R[4] * a.lx + R[5] * a.ly + R[6] * a.lz,
    v.z + R[7] * a.lx + R[8] * a.ly + R[9] * a.lz
end

local function anchorTo(v, x, y, z)
  local lx, ly, lz = toVehicle(v, x, y, z)
  return { id = v.id, lx = lx, ly = ly, lz = lz, teleports = v.teleports }
end

local function anchoredVehicle(a)
  local v = a and map and map.vehicles[a.id]
  return v and v.teleports == a.teleports and v or nil
end

local function surfable(v)
  return v.driver ~= nil or surf.TRAIN_MODELS[v.modelId] == true
end

local function surfingState(v)
  if v.driver then return ('driver %d: surfing'):format(v.driver) end
  if surfable(v) then return 'train carriage: surfing' end
  return 'no driver: no surfing, GTA ped physics'
end

local function surfGround(x, y, z)
  local g, _, what, id = groundUnder(x, y, z)
  if what ~= 'vehicle' or not g then return nil end
  local hit = g - phys.PED_Z
  if hit > z - surf.LINE_FROM or hit < z - surf.LINE_TO then return nil end
  local v = map.vehicles[id]
  return v and surfable(v) and v or nil
end

local function startSurf(b, v, t)
  b.surf = anchorTo(v, b.x, b.y, b.z)
  b.surf.contact = t
  dbg('surfing on vehicle %d model %d starts: glued at %.2f %.2f %.2f in its frame, %s', v.id, v.modelId,
    b.surf.lx, b.surf.ly, b.surf.lz, surfingState(v))
end

local function endSurf(b, why)
  dbg('surfing on vehicle %d ends at %.2f %.2f %.2f, speed %.3f %.3f %.3f: %s', b.surf.id, b.x, b.y, b.z,
    b.vx, b.vy, b.vz, why)
  b.surf = nil
end

local function comeToRest(x, y, z)
  st.restOn = nil
  if not map then return end
  local _, standing, what, id = standLine(x, y, z, true, false)
  if not standing then
    startBody(x, y, z, 0, 0, 0, ('the stand line finds nothing under %.2f %.2f %.2f, the bot is held only by bodies: %s')
      :format(x, y, z, select(2, groundUnder(x, y, z))))
    return
  end
  local v = what == 'vehicle' and map.vehicles[id]
  if v then
    st.restOn = anchorTo(v, x, y, z)
    dbg('rests on vehicle %d model %d, at %.2f %.2f %.2f in its frame, %s', id, v.modelId, st.restOn.lx,
      st.restOn.ly, st.restOn.lz, surfingState(v))
  end
end

local function startDrop(x, y, z, lostSupport)
  surroundings(x, y, z)
  st.restOn = nil
  local sx, sy, sz, hit = pushOut(x, y, z)
  if hit and (sx - x) ^ 2 + (sy - y) ^ 2 + (sz - z) ^ 2 > 1e-6 then
    dbg('body inside collision at %.2f %.2f %.2f, pushed out to %.2f %.2f %.2f by %s', x, y, z, sx, sy, sz, hit)
    x, y, z = sx, sy, sz
    sendAt(x, y, z, nil)
  end
  local target, under = groundUnder(x, y, z)
  dbg('under %.2f %.2f %.2f (map interior %d): %s', x, y, z, map and map.interior or -1, under)
  if not map then return end
  local water = map:waterLevel(x, y)
  if water and (not target or water > target - phys.PED_Z) then
    if z - phys.PED_Z < water then
      startBody(x, y, z, 0, 0, 0, ('in the water %.2f'):format(water))
      return
    end
  elseif not target then
    local over, parts = map:objectsOver(x, y), {}
    for i = 1, math.min(#over, NEARBY_OBJECTS) do
      local o = over[i]
      parts[#parts + 1] = ('object %d model %d z %.1f..%.1f'):format(o.id, o.model, o.lo, o.hi)
    end
    local n, lo, hi = map:objectIds()
    problem(('void %.0f %.0f %.0f'):format(x, y, z), 'no floor under %.2f %.2f %.2f: %s; the bot holds %d objects%s',
      x, y, z, #over > 0 and ('objects over the point: ' .. table.concat(parts, ', ') .. ', none is below the bot')
        or 'no held object covers the point',
      n, n > 0 and (', ids %d..%d'):format(lo, hi) or '')
  end
  if target and z - target <= (lostSupport and REST_GAP or DROP_MIN) then
    dbg('%.2f m above the ground at %.2f: stays at the server z, no fall', z - target, target)
    comeToRest(x, y, z)
    return
  end
  st.drop = { x = x, y = y, z = z, target = target, dz = DROP_FIRST, next = now(), from = z, t0 = now(), walked = 0 }
  event('falls from %.2f %.2f %.2f to %s (%.1f m)', x, y, z, target and ('%.2f'):format(target) or 'the void',
    target and z - target or 0)
  st.landedAt = nil
end

local function land(d)
  d.z = d.target
  sendAt(d.x, d.y, d.z, nil)
  log('landed at %.2f %.2f %.2f: %.1f m down in %.2f s', d.x, d.y, d.z, d.from - d.z, now() - d.t0)
  CFG.onLanded({ drop = d.from - d.z, time = now() - d.t0 })
  st.landedAt = now()
  d.walking = true
  if not d.fx then
    local heading = getBotRotation()
    d.fx, d.fy = -math.sin(math.rad(heading)), math.cos(math.rad(heading))
    dbg('steps forward along heading %.1f: %.2f %.2f', heading, d.fx, d.fy)
  end
end

local function fallenThroughMap(d)
  local nx, ny, nz = map:nearestPedNode(d.x, d.y, d.z, PATH_LOAD_RADIUS)
  if not nx then
    log('fell through the map at %.2f %.2f %.2f, no ped path node loaded around it: put at z %d', d.x, d.y, d.z,
      FALLEN_NO_NODE_Z)
    sendAt(d.x, d.y, FALLEN_NO_NODE_Z, nil)
    st.drop = nil
    comeToRest(d.x, d.y, FALLEN_NO_NODE_Z)
    return
  end
  log('fell through the map at %.2f %.2f %.2f: put on the ped path node %.2f %.2f %.2f', d.x, d.y, d.z, nx, ny, nz)
  d.x, d.y, d.z = nx, ny, nz + FALLEN_NODE_RAISE
  d.dz, d.from, d.t0, d.walking = DROP_FIRST, d.z, now(), nil
  d.target = groundUnder(d.x, d.y, d.z)
  sendAt(d.x, d.y, d.z, 0)
end

local function stepFall(d)
  local target, under = groundUnder(d.x, d.y, d.z)
  if target ~= d.target and not (target and d.target and math.abs(target - d.target) <= 1e-3) then
    dbg('ground under changed: %s -> %s (%s)', d.target and ('%.2f'):format(d.target) or 'void',
      target and ('%.2f'):format(target) or 'void', under)
  end
  d.target = target
  if target and target >= d.z then d.z = target end
  local from = d.z
  local x, y, z, hit, stood = d.x, d.y, d.z + d.dz, nil, false
  if not (target and target >= z) then
    x, y, z, hit, stood = moveBody(d.x, d.y, d.z, 0, 0, d.dz, false, SHIFT_FRAMES, true)
    if stood then
      target = z
    elseif hit then
      target = groundUnder(x, y, z)
    end
    d.target = target
  end
  if hit then dbg('body hit %s: %.2f %.2f %.2f -> %.2f %.2f %.2f', hit, d.x, d.y, d.z + d.dz, x, y, z) end
  d.x, d.y, d.z = x, y, z
  local w = map:waterLevel(x, y)
  if w and z - phys.PED_Z < w and not (target and target >= z) then
    local vz = d.dz / DROP_SPEED_DIV
    log('fell into the water %.2f at %.2f %.2f %.2f, %.1f m down, speed %.1f m/s', w, x, y, z, d.from - z, -vz * 50)
    startBody(x, y, z, 0, 0, vz, 'fell into the water')
    return
  end
  dbg('step z %.2f speed.z %.3f, ground at %s', d.z, d.dz / DROP_SPEED_DIV, target and ('%.2f'):format(target) or 'void')
  sendAt(d.x, d.y, d.z, d.dz / DROP_SPEED_DIV)
  d.dz = math.max(d.dz + DROP_STEP, DROP_STEP)
  if target and target >= d.z then
    land(d)
    return true
  end
  if hit and from - d.z < RESTING then
    dbg('body rests on %s at %.2f', hit, d.z)
    d.target = d.z
    land(d)
    return true
  end
  if d.z <= MAP_Z_LOW_LIMIT then fallenThroughMap(d) end
end

local function stepWalk(d)
  if d.walked > WALK_DIST + 1e-6 then
    st.drop = nil
    comeToRest(d.x, d.y, d.z)
    return
  end
  local x, y, z, hit, standing = moveBody(d.x, d.y, d.z, d.fx * WALK_STEP, d.fy * WALK_STEP, 0, true)
  if hit then dbg('step forward pushed by %s to %.2f %.2f %.2f', hit, x, y, z) end
  local g, under = groundUnder(x, y, z)
  d.x, d.y, d.z = x, y, z
  d.walked = d.walked + WALK_STEP
  if standing then
    dbg('step forward to %.2f %.2f %.2f', d.x, d.y, d.z)
    sendAt(d.x, d.y, d.z, WALK_SPEED_Z)
    return
  end
  dbg('stepped off the edge at %.2f %.2f: %s', d.x, d.y, under)
  d.walking, d.dz, d.from, d.t0, d.target = nil, DROP_FIRST, d.z, now(), g
  if stepFall(d) then stepWalk(d) end
end

local function stepDrop(d)
  if d.walking then return stepWalk(d) end
  if stepFall(d) then stepWalk(d) end
end

local function vehicleImpulse(b, c, t)
  local v = c.v
  local h = map.handling[v.modelId]
  if not h then
    problem('handling ' .. v.modelId, 'vehicle model %d has no handling in colmap.bin: its hits on the bot are skipped, the bot is only shifted out of it',
      v.modelId)
    return nil
  end
  local mf
  if b.standingOn == v.id or v.driver then
    mf = phys.MOVABLE_MASS_FACTOR
  else
    mf = 1 / (math.max(h.mass - phys.ABANDONED_FREE_MASS, 0) / phys.ABANDONED_MASS_SCALE + 1)
  end
  local nx, ny, nz = c.nx, c.ny, c.nz
  local svx, svy, svz = map:vehicleSpeed(v, t)
  local ve = svx * nx + svy * ny + svz * nz
  local vp = b.vx * nx + b.vy * ny + b.vz * nz
  local R = v.R
  local rx = c.px - v.x - (R[1] * h.cx + R[2] * h.cy + R[3] * h.cz)
  local ry = c.py - v.y - (R[4] * h.cx + R[5] * h.cy + R[6] * h.cz)
  local rz = c.pz - v.z - (R[7] * h.cx + R[8] * h.cy + R[9] * h.cz)
  local qx, qy, qz = ry * nz - rz * ny, rz * nx - rx * nz, rx * ny - ry * nx
  local mc = 1 / ((qx * qx + qy * qy + qz * qz) / (mf * h.turnMass) + 1 / (mf * h.mass))
  local mp = phys.PED_MASS
  local u = (mc * ve + mp * vp) / (mc + mp)
  local diff = vp - u
  if diff >= 0 then return nil end
  local after = b.hitWall and u or u - (phys.VEHICLE_ELASTICITY + phys.PED_ELASTICITY) * 0.5 * diff
  local j = (after - vp) * mp
  local fx, fy, fz = nx * j, ny * j, math.max(nz * j, 0)
  if b.standingOn == v.id then fx, fy = fx + fx, fy + fy end
  b.vx, b.vy, b.vz = b.vx + fx / mp, b.vy + fy / mp, b.vz + fz / mp
  return j
end

local function carFacesBot(b, v, svx, svy, svz)
  local R, lo, hi = v.R, v.model.lo, v.model.hi
  local dx, dy, dz = b.x - v.x, b.y - v.y, b.z - v.z
  local ox = R[1] * dx + R[4] * dy + R[7] * dz
  local oy = R[2] * dx + R[5] * dy + R[8] * dz
  local corner = oy >= 0 and math.atan2(hi[1], hi[2]) or math.atan2(hi[1], -lo[2])
  if math.atan2(math.abs(ox), math.abs(oy)) > corner then return false end
  local d = math.sqrt(dx * dx + dy * dy + dz * dz)
  if d == 0 then return true end
  return (dx * svx + dy * svy + dz * svz) / d > phys.HIT_CLOSING_SPEED
end

local function hitResponse(b, struck, t)
  local v = struck.v
  local svx, svy, svz = map:vehicleSpeed(v, t)
  if svx * svx + svy * svy + svz * svz <= phys.HIT_CAR_SPEED * phys.HIT_CAR_SPEED then return nil end
  local crushed = struck.nz < phys.CRUSH_NORMAL_Z
  if not crushed and not carFacesBot(b, v, svx, svy, svz) then return nil end
  if b.fallen and not b.swim then
    if map.ignored ~= v.id then
      map.ignored = v.id
      dbg('vehicle %d model %d drives over the fallen bot: its collision is ignored until they part', v.id, v.modelId)
    end
    return nil
  end
  local j = math.min(phys.PLAYER_HIT_IMPULSE_CAP, struck.j)
  if not (j > phys.HURT_IMPULSE or crushed and j > phys.CRUSH_IMPULSE) then return nil end
  b.vx, b.vy, b.vz = svx * phys.HURT_SPEED, svy * phys.HURT_SPEED, 0
  b.standing, b.fallen = false, true
  if crushed then map.ignored = v.id end
  return crushed and 'knocked down under it' or 'knocked down'
end

local function groundVehicle(b)
  return anchoredVehicle(b.anchor)
end

local function updatePosition(b, t)
  b.vz = 0
  local gx, gy, limit = 0, 0, nil
  local v = groundVehicle(b)
  if v then
    local svx, svy, svz = map:vehicleSpeed(v, t)
    local h = map.handling[v.modelId]
    local kind = h and h.kind or phys.AUTOMOBILE
    gx, gy = svx, svy
    if kind == phys.AUTOMOBILE then
      limit = phys.CAR_GROUND_SPEED_CHANGE
    elseif kind == phys.BIKE and math.sqrt(svx * svx + svy * svy + svz * svz) >= phys.BIKE_FAST_SPEED then
      limit = phys.BIKE_GROUND_SPEED_CHANGE
    end
  elseif b.fallen then
    limit = phys.FALLEN_SPEED_CHANGE
  end
  gx, gy = gx + (b.animVx or 0), gy + (b.animVy or 0)
  local cx, cy = gx - b.vx, gy - b.vy
  local m = math.sqrt(cx * cx + cy * cy)
  if limit and m > limit then cx, cy = cx * limit / m, cy * limit / m end
  b.vx, b.vy = b.vx + cx, b.vy + cy
  if b.fallen and not v and b.vx == 0 and b.vy == 0 then b.fallen = false end
end

local function collideAt(b, x, y, z, t)
  local list, hit, struck, statics = {}, false, nil, 0
  map:pedContacts(x, y, z, t, b.standing and (b.standingOn or true), b.vx, b.vy, list)
  for _, c in ipairs(list) do
    if c.kind == 'player' then
      hit = true
      local p = map.peds[c.id]
      local into = b.vx * c.nx + b.vy * c.ny + b.vz * c.nz
      local other = p and p.vx * c.nx + p.vy * c.ny + p.vz * c.nz or 0
      local u = math.min(other, 0)
      local diff = into - u
      if diff < 0 then
        local change = (b.hitWall and u or u - phys.PED_ELASTICITY * diff) - into
        b.vx, b.vy, b.vz = b.vx + c.nx * change, b.vy + c.ny * change, b.vz + c.nz * change
      end
    elseif c.kind ~= 'vehicle' then
      hit = true
      statics = statics + 1
    end
  end
  for _, c in ipairs(list) do
    if c.kind ~= 'vehicle' and c.kind ~= 'player' then
      local into = b.vx * c.nx + b.vy * c.ny + b.vz * c.nz
      if into < 0 then
        b.vx, b.vy, b.vz = b.vx - c.nx * into, b.vy - c.ny * into, b.vz - c.nz * into
        local m = math.sqrt(b.vx * b.vx + b.vy * b.vy + b.vz * b.vz)
        if m > 0 then
          local k = math.max(1 - phys.PED_ADHESION / statics * phys.FRICTION_SCALE * -into / m, 0)
          b.vx, b.vy = b.vx - b.vx / m * (m - m * k), b.vy - b.vy / m * (m - m * k)
        end
      end
    end
  end
  for _, c in ipairs(map:vehicleContacts(x, y, z, t)) do
    hit = true
    local j = vehicleImpulse(b, c, t)
    if j and (not struck or j > struck.j) then struck = { j = j, v = c.v, nz = c.nz } end
  end
  return hit, struck
end

local function surfFrame(b, t)
  map:placeVehicles(t)
  local s = b.surf
  local v = anchoredVehicle(s)
  if not v then
    endSurf(b, map.vehicles[s.id] and 'the vehicle was teleported' or 'the vehicle is gone')
    return false
  end
  local x, y, z = fromVehicle(v, s)
  local gx, gy, gz = map:vehicleSpeed(v, t)
  b.x, b.y, b.z, b.vx, b.vy, b.vz = x, y, z, gx, gy, gz
  local _, struck = collideAt(b, x, y, z, t)
  if struck and struck.v ~= v then struck.response = hitResponse(b, struck, t) end
  if struck and struck.response then
    b.anchor, b.standingOn = nil, nil
    endSurf(b, ('knocked off by vehicle %d, %s'):format(struck.v.id, struck.response))
    return true, struck
  end
  b.vx, b.vy, b.vz = gx, gy, gz
  b.standing, b.standingOn, b.anchor, b.pushedBy, b.top = true, v.id, s, nil, z
  if surfGround(x, y, z) == v then
    s.contact = t
  elseif t - s.contact >= surf.HOLD then
    b.standing, b.standingOn, b.anchor = false, nil, nil
    endSurf(b, ('the line under the bot has not found vehicle %d for %.1f s'):format(v.id, surf.HOLD))
  end
  return true, struck
end

local function relativeSpeed(b, t)
  local rel = math.sqrt(b.vx * b.vx + b.vy * b.vy + b.vz * b.vz)
  for _, v in pairs(map.vehicles) do
    local svx, svy, svz = map:vehicleSpeed(v, t)
    if svx ~= 0 or svy ~= 0 or svz ~= 0 then
      local lo, hi = v.model.lo, v.model.hi
      local size = math.sqrt(math.max(lo[1] * lo[1], hi[1] * hi[1]) + math.max(lo[2] * lo[2], hi[2] * hi[2])
        + math.max(lo[3] * lo[3], hi[3] * hi[3]))
      local reach = size + colmap.PED_RADIUS + math.sqrt(svx * svx + svy * svy + svz * svz) + rel
      local dx, dy, dz = v.x - b.x, v.y - b.y, v.z - b.z
      if dx * dx + dy * dy + dz * dz < reach * reach then
        local rx, ry, rz = b.vx - svx, b.vy - svy, b.vz - svz
        rel = math.max(rel, math.sqrt(rx * rx + ry * ry + rz * rz))
      end
    end
  end
  return rel
end

function swimFrame(b)
  local w = map:waterLevel(b.x, b.y)
  local feet = b.z - phys.PED_Z
  if not w or feet >= w then
    if b.swim then dbg('swimming ends at %.2f %.2f %.2f: out of the water', b.x, b.y, b.z) end
    b.swim = nil
    return
  end
  b.vz = b.vz + phys.BUOYANCY * math.min((w - feet) / phys.PED_HEIGHT, 1)
  if not b.swim and b.z + phys.SWIM_START < w then
    b.swim = true
    if b.surf then endSurf(b, 'in the water') end
    b.standing, b.standingOn, b.anchor = false, nil, nil
    dbg('swimming starts at %.2f %.2f %.2f, water %.2f, speed %.3f %.3f %.3f', b.x, b.y, b.z, w, b.vx, b.vy, b.vz)
  end
  if not b.swim then return end
  local k = phys.SWIM_DAMPING
  b.vx, b.vy, b.vz = b.vx * k, b.vy * k, b.vz * k
  local want = math.max(-phys.SWIM_RISE, math.min(phys.SWIM_RISE, w - phys.SWIM_DEPTH - b.z))
  b.vz = b.vz + math.max(-phys.SWIM_RISE_CHANGE, math.min(phys.SWIM_RISE_CHANGE, want - b.vz))
end

local function bladeContact(v, x, y, z)
  local hub = rotor.HUBS[v.modelId]
  if not hub or not v.driver or v.interior ~= map.interior then return false end
  local R, r = v.R, colmap.PED_RADIUS
  local hx = v.x + R[1] * hub[1] + R[2] * hub[2] + R[3] * hub[3]
  local hy = v.y + R[4] * hub[1] + R[5] * hub[2] + R[6] * hub[3]
  local hz = v.z + R[7] * hub[1] + R[8] * hub[2] + R[9] * hub[3]
  local reach = hub[4] + r
  for _, off in ipairs(colmap.PED_SPHERES) do
    local dx, dy, dz = x - hx, y - hy, z + off - hz
    local along = dx * R[3] + dy * R[6] + dz * R[9]
    if math.abs(along) <= rotor.SEMI_THICKNESS + r and dx * dx + dy * dy + dz * dz < reach * reach then return true end
  end
  return false
end

local function stepBlades(t)
  local last = st.bladeT or t
  st.bladeT = t
  if held() then return end
  local b, d = st.body, st.drop
  local x, y, z
  if b then
    x, y, z = b.x, b.y, b.z
  elseif d then
    x, y, z = d.x, d.y, d.z
  else
    x, y, z = getBotPosition()
  end
  local frames = math.min(math.max(math.floor((t - last) / PHYSICS_FRAME + 0.5), 1), rotor.MAX_FRAMES)
  for _, v in pairs(map.vehicles) do
    if bladeContact(v, x, y, z) then
      local dx, dy, dz = v.x - x, v.y - y, v.z - z
      local l = math.sqrt(dx * dx + dy * dy + dz * dz)
      if l > 1e-6 then dx, dy = dx / l, dy / l else dx, dy = 0, 0 end
      local k = rotor.PUSH / phys.PED_MASS * frames
      local vx, vy, vz = -dx * k, -dy * k, k
      local reason = ('rotor blades of vehicle %d model %d (driver %d)'):format(v.id, v.modelId, v.driver)
      if st.bladeBy ~= v.id or t - (st.bladeEventAt or -math.huge) >= rotor.EVENT_GAP then
        event('%s throw the bot', reason)
        st.bladeEventAt = t
      end
      st.bladeBy = v.id
      if b then
        if b.surf then endSurf(b, 'thrown off by rotor blades') end
        b.vx, b.vy, b.vz = b.vx + vx, b.vy + vy, b.vz + vz
        b.standing, b.standingOn, b.anchor = false, nil, nil
      else
        startBody(x, y, z, vx, vy, vz, reason)
        b = st.body
      end
      b.fallen = true
      return
    end
  end
end

local function explosion(px, py, pz, etype, source)
  local kind = blast.TYPES[etype]
  if not kind then
    problem('explosion type ' .. tostring(etype), 'explosion type %s from %s is unknown: no push', tostring(etype), source)
    return
  end
  local name, R, power = kind[1], kind[2], kind[3]
  if not map or not isBotSpawned() then return end
  local b, d = st.body, st.drop
  local x, y, z, vx, vy, vz, standing
  if b then
    x, y, z, vx, vy, vz, standing = b.x, b.y, b.z, b.vx, b.vy, b.vz, b.standing
  elseif d then
    x, y, z, vx, vy, vz, standing = d.x, d.y, d.z, 0, 0, d.walking and 0 or d.dz / DROP_SPEED_DIV, d.walking
  else
    x, y, z = getBotPosition()
    vx, vy, vz, standing = 0, 0, 0, true
  end
  local dx, dy, dz = x - px, y - py, z - pz
  local dist = math.sqrt(dx * dx + dy * dy + dz * dz)
  if dist >= R then
    dbg('%s explosion (%s) at %.2f %.2f %.2f: the bot is %.1f m away, outside its %.0f m radius', name, source, px, py, pz,
      dist, R)
    return
  end
  if power == 0 then
    dbg('%s explosion (%s) at %.2f %.2f %.2f, %.1f m away: it pushes nothing', name, source, px, py, pz, dist)
    return
  end
  local m = phys.PED_MASS
  local k = math.min(1, 2 * (R - dist) / R)
  local s = math.max(0.01, dist)
  local nx, ny, nz = dx / s, dy / s, math.max(dz / s, 0)
  local f = math.min(m / blast.MASS_SCALE * k * power, m / blast.FORCE_CAP)
  local along = (vx * nx + vy * ny + vz * nz) * m
  if along > 2 * f then f = math.max(0, f - along) end
  local jz = nz * f + (standing and blast.STANDING_LIFT or m * phys.GRAVITY)
  vx, vy, vz = vx + nx * f / m, vy + ny * f / m, vz + jz / m
  local reason = ('%s explosion (%s) at %.2f %.2f %.2f, %.1f m away'):format(name, source, px, py, pz, dist)
  event('%s throws the bot', reason)
  if b then
    if b.surf then endSurf(b, 'thrown off by the explosion') end
    b.vx, b.vy, b.vz = vx, vy, vz
    b.standing, b.standingOn, b.anchor, b.swim = false, nil, nil, nil
    dbg('%s: bot speed now %.3f %.3f %.3f', reason, vx, vy, vz)
  else
    startBody(x, y, z, vx, vy, vz, reason)
  end
  st.body.fallen = true
end

local rockets = {}
local shooters = {}

local function fireRocket(playerId, weapon, x, y, z, fx, fy, fz, t)
  local w = blast.ROCKETS[weapon]
  local l = math.sqrt(fx * fx + fy * fy + fz * fz)
  if l == 0 then return end
  fx, fy, fz = fx / l, fy / l, fz / l
  rockets[#rockets + 1] = { player = playerId, x = x, y = y, z = z, fx = fx, fy = fy, fz = fz,
                            vx = fx * w.speed, vy = fy * w.speed, vz = fz * w.speed, t = t, dies = t + w.life }
  dbg('player %d fires a rocket (weapon %d) from %.2f %.2f %.2f towards %.2f %.2f %.2f', playerId, weapon, x, y, z, fx, fy, fz)
end

local function botHit(x0, y0, z0, x1, y1, z1)
  local bx, by, bz
  if st.body then bx, by, bz = st.body.x, st.body.y, st.body.z else bx, by, bz = getBotPosition() end
  local dx, dy, dz = x1 - x0, y1 - y0, z1 - z0
  local a = dx * dx + dy * dy + dz * dz
  if a == 0 then return nil end
  local best
  for _, off in ipairs(colmap.PED_SPHERES) do
    local cx, cy, cz = bx - x0, by - y0, bz + off - z0
    local bb = cx * dx + cy * dy + cz * dz
    local c = cx * cx + cy * cy + cz * cz - colmap.PED_RADIUS * colmap.PED_RADIUS
    local disc = bb * bb - a * c
    if disc >= 0 then
      local u = (bb - math.sqrt(disc)) / a
      if u < 0 and c <= 0 then u = 0 end
      if u >= 0 and u <= 1 and (not best or u < best) then best = u end
    end
  end
  return best
end

local function stepRockets(t)
  local i = 1
  while i <= #rockets do
    local r = rockets[i]
    local gone = false
    while not gone and r.t + PHYSICS_FRAME <= t do
      r.t = r.t + PHYSICS_FRAME
      local x1, y1, z1 = r.x + r.vx, r.y + r.vy, r.z + r.vz
      local u, what = map:segmentHit(r.x, r.y, r.z, x1, y1, z1, r.t)
      local ub = botHit(r.x, r.y, r.z, x1, y1, z1)
      if ub and (not u or ub < u) then u, what = ub, 'the bot' end
      if u then
        local ex, ey, ez = r.x + (x1 - r.x) * u, r.y + (y1 - r.y) * u, r.z + (z1 - r.z) * u
        explosion(ex, ey, ez, blast.ROCKET, ('rocket of player %d hit %s'):format(r.player, what))
        gone = true
      elseif r.t >= r.dies then
        explosion(x1, y1, z1, blast.ROCKET, ('rocket of player %d burnt out'):format(r.player))
        gone = true
      else
        r.x, r.y, r.z = x1, y1, z1
        r.vx, r.vy, r.vz = r.vx + r.fx * blast.ROCKET_THRUST, r.vy + r.fy * blast.ROCKET_THRUST,
          r.vz + r.fz * blast.ROCKET_THRUST
        local sp = math.sqrt(r.vx * r.vx + r.vy * r.vy + r.vz * r.vz)
        if sp > blast.ROCKET_MAX_SPEED then
          local q = blast.ROCKET_MAX_SPEED / sp
          r.vx, r.vy, r.vz = r.vx * q, r.vy * q, r.vz * q
        end
      end
    end
    if gone then table.remove(rockets, i) else i = i + 1 end
  end
end

local thrown = {}

local function surfaceNormal(x0, y0, z0, x1, y1, z1, px, py, pz, t)
  local dx, dy, dz = x1 - x0, y1 - y0, z1 - z0
  local l = math.sqrt(dx * dx + dy * dy + dz * dz)
  dx, dy, dz = dx / l, dy / l, dz / l
  local ax, ay, az = 0, 0, 1
  if math.abs(dz) > 0.9 then ax, ay, az = 1, 0, 0 end
  local e1x, e1y, e1z = dy * az - dz * ay, dz * ax - dx * az, dx * ay - dy * ax
  local e1 = math.sqrt(e1x * e1x + e1y * e1y + e1z * e1z)
  e1x, e1y, e1z = e1x / e1, e1y / e1, e1z / e1
  local e2x, e2y, e2z = dy * e1z - dz * e1y, dz * e1x - dx * e1z, dx * e1y - dy * e1x
  local h, back, reach = blast.NORMAL_PROBE, 0.5, 1.5
  local function probe(ox, oy, oz)
    local sx, sy, sz = px - dx * back + ox, py - dy * back + oy, pz - dz * back + oz
    local u = map:segmentHit(sx, sy, sz, sx + dx * reach, sy + dy * reach, sz + dz * reach, t)
    if u then return sx + dx * reach * u, sy + dy * reach * u, sz + dz * reach * u end
  end
  local ax1, ay1, az1 = probe(e1x * h, e1y * h, e1z * h)
  local ax2, ay2, az2 = probe(e2x * h, e2y * h, e2z * h)
  if ax1 and ax2 then
    local ux, uy, uz = ax1 - px, ay1 - py, az1 - pz
    local vx, vy, vz = ax2 - px, ay2 - py, az2 - pz
    local nx, ny, nz = uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx
    local n = math.sqrt(nx * nx + ny * ny + nz * nz)
    if n > 1e-9 then
      nx, ny, nz = nx / n, ny / n, nz / n
      if nx * dx + ny * dy + nz * dz > 0 then nx, ny, nz = -nx, -ny, -nz end
      return nx, ny, nz
    end
  end
  return -dx, -dy, -dz
end

local function throwProjectile(playerId, sh, t)
  local w = blast.THROWN[sh.throwWeapon]
  local p, R = sh.pos, sh.R
  if not p or not R then return end
  local hold = math.min((sh.throwRelease or t) - sh.throwPress, blast.THROW_HOLD_MAX)
  local force = hold * blast.THROW_FORCE
  local speed = (force * blast.THROW_SPEED + blast.THROW_SPEED_MIN) * w.speed
  local fx, fy = R[2], R[5]
  local fl = math.sqrt(fx * fx + fy * fy)
  if fl < 1e-6 then return end
  fx, fy = fx / fl, fy / fl
  local h = math.atan2(-fx, fy)
  local x, y, z = p.x + fx * blast.THROW_FORWARD, p.y + fy * blast.THROW_FORWARD, p.z + blast.THROW_HAND
  if map:segmentHit(p.x, p.y, z, x, y, z, t) then
    dbg('player %d throws a %s into a wall: SA does not create it', playerId, w.name)
    return
  end
  if #thrown >= blast.MAX_PROJECTILES then table.remove(thrown, 1) end
  thrown[#thrown + 1] = { player = playerId, weapon = sh.throwWeapon, name = w.name, x = x, y = y, z = z,
                          vx = -math.sin(h) * speed, vy = math.cos(h) * speed,
                          vz = (force + 1) * blast.THROW_LIFT * speed,
                          elasticity = w.elasticity, t = t, dies = w.fuse and t + w.fuse }
  dbg('player %d throws a %s from %.2f %.2f %.2f, button held %.0f ms, force %.2f, speed %.3f', playerId, w.name, x, y, z,
    hold * 1000, force, speed)
end

local function bounce(g, x1, y1, z1, u, what)
  local px, py, pz = g.x + (x1 - g.x) * u, g.y + (y1 - g.y) * u, g.z + (z1 - g.z) * u
  local nx, ny, nz
  if what == 'the bot' then
    local bx, by
    if st.body then bx, by = st.body.x, st.body.y else bx, by = getBotPosition() end
    nx, ny, nz = px - bx, py - by, 0
    local n = math.sqrt(nx * nx + ny * ny)
    if n > 1e-6 then nx, ny = nx / n, ny / n else nx, ny, nz = surfaceNormal(g.x, g.y, g.z, x1, y1, z1, px, py, pz, g.t) end
  else
    nx, ny, nz = surfaceNormal(g.x, g.y, g.z, x1, y1, z1, px, py, pz, g.t)
  end
  local l = math.sqrt(g.vx * g.vx + g.vy * g.vy + g.vz * g.vz)
  local back = blast.THROWN_BACKOFF / l
  g.x, g.y, g.z = px - g.vx * back, py - g.vy * back, pz - g.vz * back
  local vn = g.vx * nx + g.vy * ny + g.vz * nz
  if vn < 0 then
    local tx, ty, tz = g.vx - nx * vn, g.vy - ny * vn, g.vz - nz * vn
    local tl = math.sqrt(tx * tx + ty * ty + tz * tz)
    local k = tl > 0 and math.max(0, 1 - blast.THROWN_FRICTION * (1 + g.elasticity) * -vn / tl) or 0
    local e = g.elasticity
    g.vx, g.vy, g.vz = tx * k - nx * vn * e, ty * k - ny * vn * e, tz * k - nz * vn * e
  end
  if what == 'map' and nz > 0.7 and math.sqrt(g.vx * g.vx + g.vy * g.vy + g.vz * g.vz) < blast.SETTLE_SPEED then
    g.vx, g.vy, g.vz, g.rest = 0, 0, 0, true
    dbg('%s of player %d lies at %.2f %.2f %.2f', g.name, g.player, g.x, g.y, g.z)
  end
end

local function stepThrown(t)
  local i = 1
  while i <= #thrown do
    local g = thrown[i]
    local gone = false
    while not gone and g.t + PHYSICS_FRAME <= t do
      g.t = g.t + PHYSICS_FRAME
      if g.dies and g.t >= g.dies then
        explosion(g.x, g.y, g.z, blast.GRENADE, ('%s of player %d'):format(g.name, g.player))
        gone = true
      elseif g.rest then
        if not g.dies then g.t = t end
      else
        g.vz = g.vz - phys.GRAVITY
        local x1, y1, z1 = g.x + g.vx, g.y + g.vy, g.z + g.vz
        local u, what = map:segmentHit(g.x, g.y, g.z, x1, y1, z1, g.t)
        local ub = botHit(g.x, g.y, g.z, x1, y1, z1)
        if ub and (not u or ub < u) then u, what = ub, 'the bot' end
        if u then bounce(g, x1, y1, z1, u, what) else g.x, g.y, g.z = x1, y1, z1 end
        if g.elasticity > 0.1 and math.abs(g.vx) < blast.SETTLE_SPEED and math.abs(g.vy) < blast.SETTLE_SPEED
            and math.abs(g.vz) < blast.SETTLE_SPEED then
          g.elasticity = blast.SETTLE_ELASTICITY
        end
      end
    end
    if gone then table.remove(thrown, i) else i = i + 1 end
  end
end

local function detonate(playerId)
  local i, n = 1, 0
  while i <= #thrown do
    local g = thrown[i]
    if g.weapon == blast.SATCHEL then
      table.remove(thrown, i)
      n = n + 1
      explosion(g.x, g.y, g.z, blast.GRENADE, ('satchel charge of player %d, detonator of player %d'):format(g.player,
        playerId))
    else
      i = i + 1
    end
  end
  if n == 0 then dbg('player %d uses the detonator: no satchel charges known', playerId) end
end

local function stepThrows(t)
  for playerId, sh in pairs(shooters) do
    if sh.throwAt and t >= sh.throwAt then
      sh.throwAt = nil
      throwProjectile(playerId, sh, t)
    end
  end
end

local function animRoot(a, tau)
  local k = a.keys
  if not k then return 0, 0 end
  local n = #k / 3
  if tau <= k[1] then return k[2], k[3] end
  for i = 2, n do
    local t1 = k[3 * i - 2]
    if tau <= t1 then
      local t0 = k[3 * i - 5]
      local f = (tau - t0) / (t1 - t0)
      return k[3 * i - 4] + (k[3 * i - 1] - k[3 * i - 4]) * f, k[3 * i - 3] + (k[3 * i] - k[3 * i - 3]) * f
    end
  end
  return k[3 * n - 1], k[3 * n]
end

local function animAt(p, tau)
  local a = p.anim
  if p.still then return 0, 0 end
  if tau < 0 then tau = 0 end
  if p.loop then
    local c = math.floor(tau / a.length)
    local x, y = animRoot(a, tau - c * a.length)
    local x1, y1 = animRoot(a, a.length)
    local x0, y0 = animRoot(a, 0)
    return x + c * (x1 - x0), y + c * (y1 - y0)
  end
  return animRoot(a, math.min(tau, a.length))
end

function animFrame(b, t)
  local p = st.anim
  if not p or p.t0 > t then
    b.animVx, b.animVy = 0, 0
    return
  end
  local x0, y0 = animAt(p, (t - PHYSICS_FRAME - p.t0) * p.speed)
  local x1, y1 = animAt(p, (t - p.t0) * p.speed)
  local dx, dy = x1 - x0, y1 - y0
  local c, s = math.cos(p.h), math.sin(p.h)
  b.animVx, b.animVy = dx * c - dy * s, dx * s + dy * c
end

local function botControl()
  if not map or not isBotSpawned() or held() or st.drop then return nil end
  local b = st.body
  if b and (not b.standing or b.surf or b.swim) then return nil end
  if b then return b.x, b.y, b.z end
  local x, y, z = getBotPosition()
  local _, standing = standLine(x, y, z, true, false)
  if not standing then return nil end
  return x, y, z
end

local function playAnim(name, t, opts, reason)
  local x, y, z = botControl()
  if not x then return false end
  local a = fight.ANIMS[name]
  local h = math.rad(getBotRotation() or 0)
  st.anim = { name = name, anim = a, t0 = t, speed = opts.speed or 1, h = h, loop = opts.loop, ends = opts.ends,
              fall = opts.fall, still = opts.still }
  local dx, dy = animAt(st.anim, a.length)
  dbg('%s: plays %s (anim %d)%s, heading %.0f, root moves %.2f m%s', reason, name, a.id,
    opts.loop and (' looped, speed %.2f'):format(st.anim.speed) or '', math.deg(h), math.sqrt(dx * dx + dy * dy),
    opts.fall and ', falls and gets up' or '')
  if not st.body then startBody(x, y, z, 0, 0, 0, reason) end
  event('%s: plays %s', reason, name)
  return true
end

local function stepAnim(t)
  local p = st.anim
  if not p then return end
  local done
  if p.loop then
    done = t >= p.ends
  else
    done = (t - p.t0) * p.speed >= p.anim.length
  end
  if not done then return end
  if p.fall then
    st.anim = { name = 'getup', anim = fight.ANIMS.getup, t0 = t, speed = 1, h = p.h }
    dbg('%s ends on the ground: getup (anim %d)', p.name, fight.ANIMS.getup.id)
  else
    st.anim = nil
    dbg('%s ends', p.name)
  end
end

local function localDirection(ax, ay, bx, by)
  local rel = math.atan2(-(ax - bx), ay - by) - math.rad(getBotRotation() or 0) + math.pi / 4
  rel = rel % (2 * math.pi)
  return math.floor(rel / (math.pi / 2)) % 4
end

local function meleeHit(playerId, sh, t)
  local m = sh.melee
  sh.melee = nil
  local combo = fight.COMBOS[m.combo]
  if st.anim and (st.anim.fall or st.anim.name == 'getup') then return end
  local p, R = sh.pos, sh.R
  if not p or not R then return end
  local x, y, z = botControl()
  if not x then return end
  local fx, fy = R[2], R[5]
  local fl = math.sqrt(fx * fx + fy * fy)
  if fl < 1e-6 then return end
  fx, fy = fx / fl, fy / fl
  local sx, sy = p.x + fx * fight.FORWARD, p.y + fy * fight.FORWARD
  local sz = p.z + fight.LEVELS[combo.level[m.move]]
  local reach = combo.radius[m.move] + colmap.PED_RADIUS
  local best = math.huge
  for _, off in ipairs(colmap.PED_SPHERES) do
    local d = math.sqrt((x - sx) ^ 2 + (y - sy) ^ 2 + (z + off - sz) ^ 2)
    if d < best then best = d end
  end
  if best >= reach then
    dbg('player %d %s move %d misses: strike point %.2f m from the bot, reach %.2f', playerId, m.combo, m.move, best, reach)
    return
  end
  local dir = localDirection(p.x, p.y, x, y)
  local name, fall = nil, false
  if dir == 0 and m.move <= 3 then
    name = combo.hits[m.move]
    fall = math.floor(combo.flags / (fight.COMBO_FALL * 2 ^ (m.move - 1))) % 2 == 1
  elseif dir == 0 then
    name = combo.damage[m.move] > fight.HEAVY_HIT and 'hit_walk' or 'hit_front'
  else
    name = fight.DIRECTION_HITS[dir]
  end
  playAnim(name, t, { fall = fall }, ('player %d hits the bot (%s move %d, %s)'):format(playerId, m.combo, m.move,
    ({ [0] = 'from the front', 'from the left', 'from behind', 'from the right' })[dir]))
end

local function sprayHit(playerId, sh, t)
  local w = fight.SPRAYS[sh.spray]
  local p = sh.pos
  local x, y, z = botControl()
  if not x or not p then return end
  local dx, dy, dz
  local aim = sh.aim and t - sh.aimAt <= blast.AIM_FRESH and sh.aim
  if aim then
    dx, dy, dz = aim.camFront.x, aim.camFront.y, aim.camFront.z
  elseif sh.R then
    dx, dy, dz = sh.R[2], sh.R[5], sh.R[8]
  else
    return
  end
  local l = math.sqrt(dx * dx + dy * dy + dz * dz)
  if l < 1e-6 then return end
  dx, dy, dz = dx / l, dy / l, dz / l
  local hl = math.sqrt(dx * dx + dy * dy)
  local ox, oy, oz = p.x, p.y, p.z + fight.SPRAY_HAND
  if hl > 1e-6 then ox, oy = ox + dx / hl * fight.SPRAY_FORWARD, oy + dy / hl * fight.SPRAY_FORWARD end
  local len = w.speed * fight.SPRAY_LIFE / PHYSICS_FRAME
  local along = math.max(0, math.min(len, (x - ox) * dx + (y - oy) * dy + (z - oz) * dz))
  local cx, cy, cz = ox + dx * along, oy + dy * along, oz + dz * along
  local d = math.sqrt((x - cx) ^ 2 + (y - cy) ^ 2 + (z - cz) ^ 2)
  if d >= fight.SPRAY_RANGE then return end
  local at = t + along / w.speed * PHYSICS_FRAME
  local ends = at + fight.CHOKE_MIN + math.random() * (fight.CHOKE_MAX - fight.CHOKE_MIN)
  local p0 = st.anim
  if p0 and p0.name == 'gas_cwr' then
    if ends > p0.ends then p0.ends = ends end
    return
  end
  if p0 then return end
  playAnim('gas_cwr', at, { loop = true, ends = ends,
                            speed = fight.CHOKE_SPEED_MIN + math.random() * (fight.CHOKE_SPEED_MAX - fight.CHOKE_SPEED_MIN) },
    ('%s of player %d reaches the bot %.1f m from the nozzle'):format(w.name, playerId, along))
end

local function bodyPiece(ox, oy, oz)
  if oz >= fight.HEAD_Z then return 'head' end
  local h = math.rad(getBotRotation() or 0)
  local side = ox * math.cos(h) + oy * math.sin(h)
  if oz < fight.LEG_Z then return side > 0 and 'right_leg' or 'left_leg' end
  if side >= fight.ARM_SIDE then return 'right_arm' end
  if side <= -fight.ARM_SIDE then return 'left_arm' end
  return 'torso'
end

local function bulletHit(playerId, data, t)
  if data.targetType ~= fight.BULLET_TARGET_PLAYER or data.targetId ~= getBotId() then return end
  local weapon = data.weaponId
  if not fight.HEAVY_BULLETS[weapon] then return end
  if t < (st.bulletAnimReady or 0) then
    dbg('player %d shoots the bot with weapon %d: no hit animation, the last one was under %.1f s ago', playerId, weapon,
      fight.BULLET_HIT_DELAY)
    return
  end
  if (st.sentSpeed or 0) > fight.STANDING_SPEED or (st.movedAt and t - st.movedAt < fight.MOVED_RECENTLY) then
    dbg('player %d shoots the bot with weapon %d: the bot is moving, no hit animation', playerId, weapon)
    return
  end
  local x, y = botControl()
  if not x then return end
  local o = data.center
  local piece = bodyPiece(o.x, o.y, o.z)
  local dir = localDirection(data.origin.x, data.origin.y, x, y)
  local name = fight.PIECE_HITS[piece][dir]
  local variants = fight.PIECE_VARIANTS[piece]
  if variants and st.anim and st.anim.name == name then
    repeat name = variants[math.random(#variants)] until name ~= st.anim.name
  end
  if playAnim(name, t, { still = not fight.EXTRACTS_VELOCITY[name] },
      ('player %d shoots the bot in the %s with weapon %d %s'):format(playerId, (piece:gsub('_', ' ')), weapon,
        ({ [0] = 'from the front', 'from the left', 'from behind', 'from the right' })[dir])) then
    st.bulletAnimReady = t + fight.BULLET_HIT_DELAY
  end
end

local function stepFights(t)
  for playerId, sh in pairs(shooters) do
    if sh.melee and t >= sh.melee.at then meleeHit(playerId, sh, t) end
    if sh.spray and sh.fire and t - (sh.syncAt or 0) <= fight.SPRAY_FRESH then sprayHit(playerId, sh, t) end
  end
  stepAnim(t)
end

local function shooter(playerId)
  local sh = shooters[playerId]
  if not sh then
    sh = {}
    shooters[playerId] = sh
  end
  return sh
end

local function freshAim(sh, t)
  return sh.aim and t - sh.aimAt <= blast.AIM_FRESH and sh.aim or nil
end

local function tankShot(playerId, v, sh, t)
  local R = v.R
  local vert, horiz = 0, 0
  local aim = freshAim(sh, t)
  if aim then
    local f = aim.camFront
    local lx = R[1] * f.x + R[4] * f.y + R[7] * f.z
    local ly = R[2] * f.x + R[5] * f.y + R[8] * f.z
    local lz = R[3] * f.x + R[6] * f.y + R[9] * f.z
    vert = math.atan2(-lx, ly)
    horiz = math.atan2(lz, math.sqrt(lx * lx + ly * ly)) + blast.TANK_LIFT
  end
  horiz = math.max(-blast.TANK_DOWN, math.min(blast.TANK_UP, horiz))
  local sv, cv = math.sin(vert), math.cos(vert)
  local P, T = blast.TANK_POS, blast.TANK_TARGET
  local ox, oy = T[1] - P[1], T[2] - P[2]
  local lx = P[1] + cv * ox - sv * oy
  local ly = P[2] + cv * oy + sv * ox
  local lz = P[3] + T[3] - P[3] - 1
  local sx = v.x + R[1] * lx + R[2] * ly + R[3] * lz
  local sy = v.y + R[4] * lx + R[5] * ly + R[6] * lz
  local sz = v.z + R[7] * lx + R[8] * ly + R[9] * lz
  local ax, ay, az = math.sin(-vert), math.cos(vert), math.sin(horiz)
  local dx = R[1] * ax + R[2] * ay + R[3] * az
  local dy = R[4] * ax + R[5] * ay + R[6] * az
  local dz = R[7] * ax + R[8] * ay + R[9] * az
  local ex, ey, ez = sx + dx * blast.TANK_RANGE, sy + dy * blast.TANK_RANGE, sz + dz * blast.TANK_RANGE
  local u, what = map:segmentHit(sx, sy, sz, ex, ey, ez, t, v.id)
  local ub = botHit(sx, sy, sz, ex, ey, ez)
  if ub and (not u or ub < u) then u, what = ub, 'the bot' end
  local px, py, pz = ex, ey, ez
  if u then
    px, py, pz = sx + (ex - sx) * u, sy + (ey - sy) * u, sz + (ez - sz) * u
    px, py, pz = px - (px - sx) * blast.TANK_BACKOFF, py - (py - sy) * blast.TANK_BACKOFF, pz - (pz - sz) * blast.TANK_BACKOFF
  end
  explosion(px, py, pz, blast.TANK_FIRE, ('tank %d of player %d, turret %s, hit %s'):format(v.id, playerId,
    aim and 'from the aim sync' or 'straight ahead, no aim sync', what or 'nothing in 60 m'))
end

local function pedFrame(b, t)
  local t0 = t - PHYSICS_FRAME
  map:placeVehicles(t0)
  if b.surf then
    local glued, struck = surfFrame(b, t)
    if glued then return struck end
  end
  local gv = groundVehicle(b)
  local gx, gy, gz = 0, 0, 0
  if gv then
    b.x, b.y, b.z = fromVehicle(gv, b.anchor)
    gx, gy, gz = map:vehicleSpeed(gv, t)
  else
    b.anchor = nil
  end
  animFrame(b, t)
  if b.standing and not b.swim then updatePosition(b, t) end
  if not b.standing or b.swim then
    b.vz = b.vz - phys.GRAVITY
    local k = math.max(0, 1 - math.sqrt(b.vx * b.vx + b.vy * b.vy + b.vz * b.vz) * phys.AIR)
    b.vx, b.vy, b.vz = b.vx * k, b.vy * k, b.vz * k
  end
  swimFrame(b)
  local speed = relativeSpeed(b, t)
  local steps = speed < phys.COLLISION_STEP and 1 or math.max(2, math.ceil(speed / phys.COLLISION_STEP))
  local ox, oy, oz = b.x, b.y, b.z
  local vx, vy, vz = b.vx, b.vy, b.vz
  local struck
  for i = 1, steps do
    local f = i / steps
    local hit
    map:placeVehicles(t0 + f * PHYSICS_FRAME)
    hit, struck = collideAt(b, ox + vx * f, oy + vy * f, oz + vz * f, t)
    if hit then break end
  end
  map:placeVehicles(t)
  if struck then struck.response = hitResponse(b, struck, t) end
  local was = b.standing
  if was and struck and not struck.response and struck.v.id ~= b.standingOn and b.vz > 0 then b.vz = 0 end
  local x, y, z = ox + b.vx, oy + b.vy, oz + b.vz
  local on = was and (b.standingOn or true)
  local ceiling = select(9, map:pedContacts(x, y, z, t, on, b.vx, b.vy))
  local standing, what, id = false, nil, nil
  z, standing, what, id = standLine(x, y, z, was, ceiling)
  if was and not b.standingOn and what == 'vehicle' and z > oz + RESTING then
    if not b.refusedClimb then
      dbg('ped physics: vehicle %d rises under the bot standing on the ground, the bot is pushed, not lifted onto it', id)
    end
    b.refusedClimb = true
    z, what, id = oz, nil, nil
  end
  if b.swim then standing = false end
  if standing then
    if not was then b.landed = { speed = -b.vz, drop = b.top - z } end
    b.vz = 0
  else
    b.top = math.max(b.top, z)
  end
  b.standing, b.standingOn = standing, what == 'vehicle' and id or nil
  local sx, sy, sz, hit = map:shiftPed(x, y, z, t, standing and (b.standingOn or true), b.vx, b.vy)
  if hit then x, y, z = sx, sy, sz end
  b.hitWall = hit ~= nil and hit.kind ~= 'vehicle' and hit.kind ~= 'player'
  local pushedBy = hit and ('%s %s'):format(hit.kind, hit.id or hit.model) or nil
  if pushedBy and pushedBy ~= b.pusher then
    dbg('ped physics: pushed out by %s, %.2f m deep, normal %.2f %.2f %.2f, to %.2f %.2f %.2f', pushedBy, hit.depth,
      hit.nx, hit.ny, hit.nz, x, y, z)
    b.pusher, b.pushStart = pushedBy, { b.x, b.y, b.z }
  end
  b.pushedBy = pushedBy
  b.x, b.y, b.z = x, y, z
  local sv = b.standingOn and map.vehicles[b.standingOn]
  local was = b.anchor and b.anchor.id
  b.anchor = sv and anchorTo(sv, x, y, z) or nil
  if sv and sv.id ~= was then
    dbg('ped physics: stands on vehicle %d model %d, at %.2f %.2f %.2f in its frame, speed %.3f %.3f %.3f, vehicle %.3f %.3f %.3f, %s',
      sv.id, sv.modelId, b.anchor.lx, b.anchor.ly, b.anchor.lz, b.vx, b.vy, b.vz, gx, gy, gz, surfingState(sv))
  elseif was and not sv then
    dbg('ped physics: leaves vehicle %d at %.2f %.2f %.2f, speed %.3f %.3f %.3f, %s', was, x, y, z, b.vx, b.vy, b.vz,
      standing and ('now on ' .. tostring(what)) or 'in the air')
  end
  local surfOn = standing and not b.fallen and b.standingOn and surfGround(x, y, z)
  if surfOn and surfOn.id ~= b.standingOn then surfOn = nil end
  if surfOn then startSurf(b, surfOn, t) end
  return struck
end

function startBody(x, y, z, vx, vy, vz, reason, anchor, since)
  st.drop, st.restOn, st.pending = nil, nil, nil
  local av = anchoredVehicle(anchor)
  if av then x, y, z = fromVehicle(av, anchor) end
  local _, standing, what, id = standLine(x, y, z, vz <= 0, false)
  standing = standing and vz <= 0
  local standingOn = standing and what == 'vehicle' and id or nil
  local sv = standingOn and map.vehicles[standingOn]
  st.body = { x = x, y = y, z = z, vx = vx, vy = vy, vz = vz, standing = standing, top = z, t = since or now(), hitWall = false,
              standingOn = standingOn, anchor = sv and anchorTo(sv, x, y, z) or nil }
  dbg('ped physics starts at %.2f %.2f %.2f, speed %.3f %.3f %.3f (%s)', x, y, z, vx, vy, vz, reason)
  local surfOn = standingOn and surfGround(x, y, z)
  if surfOn and surfOn.id ~= standingOn then surfOn = nil end
  if surfOn then startSurf(st.body, surfOn, st.body.t) end
end

local function stepRest(t)
  local r = st.restOn
  local v = anchoredVehicle(r)
  local bx, by, bz = getBotPosition()
  if not v then
    dbg('vehicle %d under the bot is %s', r.id, map.vehicles[r.id] and 'teleported, the bot stays in place' or 'gone')
    comeToRest(bx, by, bz)
    return
  end
  local x, y, z = fromVehicle(v, r)
  local gx, gy, gz = map:vehicleSpeed(v, t)
  local shift = math.sqrt((x - bx) ^ 2 + (y - by) ^ 2 + (z - bz) ^ 2)
  if gx ~= 0 or gy ~= 0 or gz ~= 0 or shift > RESTING then
    startBody(bx, by, bz, 0, 0, 0, ('vehicle %d under the bot moves, speed %.3f %.3f %.3f, %.2f m since the bot came to rest, %s')
      :format(v.id, gx, gy, gz, shift, surfingState(v)), r)
  end
end

local BODY_MAX_FRAMES = 25
local HIT_EVENT_GAP = 2
local BODY_REPORT = 0.5

local function stepBody(t)
  local b = st.body
  local frames = math.floor((t - b.t) / PHYSICS_FRAME)
  if frames < 1 then return end
  b.t = b.t + frames * PHYSICS_FRAME
  frames = math.min(frames, BODY_MAX_FRAMES)
  local moving = false
  for k = 1, frames do
    local tf = b.t - (frames - k) * PHYSICS_FRAME
    local struck = pedFrame(b, tf)
    local ground = groundVehicle(b)
    local gx, gy, gz = 0, 0, 0
    if ground then gx, gy, gz = map:vehicleSpeed(ground, tf) end
    local frameStill = b.standing and not b.fallen and not struck and not b.pushedBy and not st.anim
      and b.vx == 0 and b.vy == 0 and b.vz == 0 and gx == 0 and gy == 0 and gz == 0
    b.stillFrames = frameStill and (b.stillFrames or 0) + 1 or 0
    if struck then
      local v = struck.v
      b.hits = (b.hits or 0) + 1
      if struck.response or b.hitBy ~= v.id then
        local svx, svy, svz = map:vehicleSpeed(v, tf)
        dbg('hit by vehicle %d model %d (%s, %.1f km/h): impulse %.1f, %s, bot speed now %.3f %.3f %.3f%s', v.id,
          v.modelId, v.driver and ('driver %d'):format(v.driver) or 'no driver',
          math.sqrt(svx * svx + svy * svy + svz * svz) * 50 * 3.6, struck.j, struck.response or 'pushed', b.vx, b.vy, b.vz,
          struck.response and '' or ', further pushes by it are counted, not logged')
        if b.hitBy ~= v.id or tf - (b.hitEventAt or -math.huge) >= HIT_EVENT_GAP then
          b.hitEventAt = tf
          event('hit by vehicle %d model %d (%s, %.1f km/h): %s', v.id, v.modelId,
            v.driver and ('driver %d'):format(v.driver) or 'no driver', math.sqrt(svx * svx + svy * svy + svz * svz) * 50 * 3.6,
            struck.response or 'pushed')
        end
        b.hitBy = v.id
      end
      moving = true
    end
    if b.landed and b.landed.drop < REST_GAP then
      b.landed = nil
    end
    if b.landed then
      log('landed at %.2f %.2f %.2f: %.1f m down, %.1f m/s', b.x, b.y, b.z, b.landed.drop, b.landed.speed * 50)
      CFG.onLanded(b.landed)
      b.landed, b.top = nil, b.z
    end
    if b.z <= MAP_Z_LOW_LIMIT then
      local nx, ny, nz = map:nearestPedNode(b.x, b.y, b.z, PATH_LOAD_RADIUS)
      log('fell through the map at %.2f %.2f %.2f: %s', b.x, b.y, b.z,
        nx and ('put on the ped path node %.2f %.2f %.2f'):format(nx, ny, nz) or ('no ped path node, put at z %d'):format(FALLEN_NO_NODE_Z))
      b.x, b.y, b.z = nx or b.x, ny or b.y, nx and nz + FALLEN_NODE_RAISE or FALLEN_NO_NODE_Z
      b.vx, b.vy, b.vz, b.standing, b.top, b.anchor, b.standingOn = 0, 0, 0, false, b.z, nil, nil
    end
  end
  map:placeVehicles(t)
  setBotPosition(b.x, b.y, b.z)
  if t - (b.reported or 0) >= BODY_REPORT then
    b.reported = t
    dbg('ped physics at %.2f %.2f %.2f, speed %.3f %.3f %.3f, %s%s%s, under: %s', b.x, b.y, b.z, b.vx, b.vy, b.vz,
      b.standing and 'standing' or 'in the air', b.standingOn and (' on vehicle %d'):format(b.standingOn) or '',
      b.fallen and ', fallen' or '', select(2, groundUnder(b.x, b.y, b.z)))
  end
  if b.stillFrames >= colmap.STATIC_FRAMES then
    if b.pusher then
      local p0 = b.pushStart
      dbg('ped physics: nothing pushes the bot any more, moved %.2f m since %s first pushed it, %d vehicle hits',
        math.sqrt((b.x - p0[1]) ^ 2 + (b.y - p0[2]) ^ 2 + (b.z - p0[3]) ^ 2), b.pusher, b.hits or 0)
    end
    dbg('ped physics rests at %.2f %.2f %.2f', b.x, b.y, b.z)
    st.body = nil
    st.lastSync = t
    updateSync()
    comeToRest(b.x, b.y, b.z)
  elseif t - st.lastSync >= (CFG.fallSyncRate or st.onfootRate) / 1000 then
    st.lastSync = t
    updateSync()
  end
end

local function bodyTouchesBot(t, since)
  local x, y, z = getBotPosition()
  local list = map:vehicleContacts(x, y, z, t)
  if #list > 0 then
    local v = list[1].v
    startBody(x, y, z, 0, 0, 0, ('vehicle %d model %d touches the bot, the physics starts from the previous tick %.0f ms ago')
      :format(v.id, v.modelId, (t - since) * 1000), nil, since)
    return true
  end
  local touching = {}
  map:pedContacts(x, y, z, t, false, 0, 0, touching)
  for _, c in ipairs(touching) do
    if c.kind == 'player' then
      startBody(x, y, z, 0, 0, 0, 'a player touches the bot')
      return true
    end
  end
  return false
end

local function tick()
  if not isBotSpawned() then
    st.pending, st.drop, st.placed, st.restOn, st.body = nil, nil, nil, nil, nil
    return
  end
  local t = now()
  if map and #rockets > 0 then stepRockets(t) end
  if map then stepThrows(t) end
  if map then stepFights(t) end
  if map and #thrown > 0 then stepThrown(t) end
  if map and map.ignored then
    local v = map.vehicles[map.ignored]
    local x, y, z = getBotPosition()
    if not v or not map:vehicleTouchesPed(v, x, y, z) then
      dbg('vehicle %d no longer touches the bot: its collision counts again', map.ignored)
      map.ignored = nil
    end
  end
  local since = math.max(st.lastTick or t, t - BODY_MAX_FRAMES * PHYSICS_FRAME)
  st.lastTick = t
  if map then map:advanceVehicles(t) end
  if map then stepBlades(t) end
  local p = st.pending
  if p and not held() then
    st.pending = nil
    dbg('fall check %.0f ms after SetPlayerPos', (t - p.set) * 1000)
    startDrop(p.x, p.y, p.z)
  end
  local d = st.drop
  if d then
    if held() then
      d.next = t
    elseif t >= d.next then
      d.next = math.max(d.next + DROP_TICK, t)
      stepDrop(d)
    end
    return
  end
  if not map then return end
  if held() then
    if st.body then st.body.t = t end
    return
  end
  if st.body then return stepBody(t) end
  if st.restOn then
    stepRest(t)
    if st.body then return end
  end
  bodyTouchesBot(t, since)
end

local WATCH_JUMP = 1
local WATCH_MOVE = 1e-3
local WATCH_PUSH_GAP = 0.25

local function movedOutside(x, y, z, w)
  if st.pending or held() or not map or not isBotSpawned() then return end
  local dx, dy, dz = x - w[1], y - w[2], z - w[3]
  local jump = dx * dx + dy * dy + dz * dz > WATCH_JUMP * WATCH_JUMP
  local t = now()
  local last = st.movedAt and t - st.movedAt <= WATCH_PUSH_GAP and st.movedAt or w[4]
  st.movedAt = t
  local frames = math.max((t - last) / PHYSICS_FRAME, 1)
  local vx, vy = 0, 0
  if not jump then vx, vy = dx / frames, dy / frames end
  local d, b = st.drop, st.body
  if d then
    d.x, d.y, d.z = x, y, z
    return
  end
  if b then
    if b.surf then endSurf(b, 'moved by another script') end
    b.x, b.y, b.z, b.anchor, b.standingOn = x, y, z, nil, nil
    if not jump then b.vx, b.vy = vx, vy end
    return
  end
  local _, standing, _, _ = standLine(x, y, z, true, false)
  if standing then
    if st.restOn or jump then comeToRest(x, y, z) end
    return
  end
  if jump then
    dbg('moved by another script to %.2f %.2f %.2f, nothing under the feet: fall check', x, y, z)
    startDrop(x, y, z, true)
  else
    startBody(x, y, z, vx, vy, 0, ('moved by another script %.2f m, nothing under the feet: %s')
      :format(math.sqrt(dx * dx + dy * dy + dz * dz), select(2, groundUnder(x, y, z))))
  end
end

local function watchedTick()
  local x, y, z = getBotPosition()
  local w = st.watch
  if w and (x - w[1]) ^ 2 + (y - w[2]) ^ 2 + (z - w[3]) ^ 2 > WATCH_JUMP * WATCH_JUMP then
    dbg('bot moved outside slapfix: %.2f %.2f %.2f -> %.2f %.2f %.2f%s', w[1], w[2], w[3], x, y, z,
      st.placed and ('; last SetPlayerPos %.2f %.2f %.2f was %.0f ms ago'):format(st.placed.x, st.placed.y,
        st.placed.z, (now() - st.placed.set) * 1000) or '; no SetPlayerPos yet')
  end
  if w and (x - w[1]) ^ 2 + (y - w[2]) ^ 2 + (z - w[3]) ^ 2 > WATCH_MOVE * WATCH_MOVE then movedOutside(x, y, z, w) end
  tick()
  local ax, ay, az = getBotPosition()
  st.watch = { ax, ay, az, now() }
end

registerHandler('onUpdate', watchedTick)

function sampev.onSetPlayerPos(pos)
  local bx, by, bz = getBotPosition()
  dbg('SetPlayerPos %.2f %.2f %.2f from %.2f %.2f %.2f, map interior %d, bot interior %s', pos.x, pos.y, pos.z,
    bx, by, bz, map and map.interior or -1, tostring(getBotInterior and getBotInterior()))
  if not CFG.enabled then return end
  st.drop, st.restOn, st.body = nil, nil, nil
  st.pending = { x = pos.x, y = pos.y, z = pos.z, set = now() }
  st.created, st.noCollision, st.destroyed, st.removed = 0, 0, 0, 0
  st.placed = st.pending
end

function sampev.onSetPlayerPosFindZ(pos)
  if not CFG.enabled or not CFG.findZ or not map then return end
  st.pending, st.body = nil, nil
  local g, w, what, model, int, objectId = map:groundTop(pos.x, pos.y, math.max(pos.z, 1000))
  dbg('SetPlayerPosFindZ %.2f %.2f %.2f (map interior %d): %s', pos.x, pos.y, pos.z, map.interior,
    describe(g, w, what, model, int, objectId))
  if g then
    pos.z = g + phys.PED_Z
    return { pos }
  end
end

function sampev.onSetPlayerVelocity(v)
  if not CFG.enabled or not map then return end
  event('SetPlayerVelocity %.3f %.3f %.3f', v.x, v.y, v.z)
  local b = st.body
  if b then
    b.vx, b.vy, b.vz = v.x, v.y, v.z
    if v.z > 0 then b.standing = false end
    return
  end
  local x, y, z = getBotPosition()
  startBody(x, y, z, v.x, v.y, v.z, 'SetPlayerVelocity')
end

function sampev.onSetGravity(gravity)
  phys.GRAVITY = gravity
  log('gravity %.4f', gravity)
end

function sampev.onTogglePlayerControllable(controllable)
  dbg('TogglePlayerControllable %s', tostring(controllable))
  st.frozen = not controllable
end

function sampev.onSetInterior(interior)
  dbg('SetPlayerInterior %d (was %d)%s', interior, map and map.interior or -1, st.drop and ', while falling' or '')
  if map then map:setInterior(interior) end
  local p = st.placed
  if st.drop and p then
    dbg('interior changed while falling: the fall starts again from %.2f %.2f %.2f', p.x, p.y, p.z)
    st.drop = nil
    setBotPosition(p.x, p.y, p.z)
    startDrop(p.x, p.y, p.z)
  end
end

function sampev.onSendPlayerSync(data)
  local b = st.body
  st.sentSpeed = math.sqrt(data.moveSpeed.x ^ 2 + data.moveSpeed.y ^ 2)
  local sv, px, py, pz
  if b then
    sv, px, py, pz = anchoredVehicle(b.surf), b.x, b.y, b.z
  else
    sv = anchoredVehicle(st.restOn)
    if sv and not surfable(sv) then sv = nil end
    px, py, pz = getBotPosition()
  end
  local surfing = sv ~= nil
  if surfing then
    local o = data.surfingOffsets
    data.surfingVehicleId = sv.id
    if b then
      o.x, o.y, o.z = b.surf.lx, b.surf.ly, b.surf.lz
      b.x, b.y, b.z = fromVehicle(sv, b.surf)
    else
      o.x, o.y, o.z = toVehicle(sv, px, py, pz)
    end
  end
  if st.anim and st.anim.t0 <= now() then data.animationId = st.anim.anim.id end
  if st.speedZ then
    data.moveSpeed.z = st.speedZ
  elseif b then
    data.position.x, data.position.y, data.position.z = b.x, b.y, b.z
    data.moveSpeed.x, data.moveSpeed.y, data.moveSpeed.z = b.vx, b.vy, b.vz
    dbg('packet ped physics: %.2f %.2f %.2f speed %.3f %.3f %.3f', b.x, b.y, b.z, b.vx, b.vy, b.vz)
  end
  if st.drop or (st.landedAt and now() - st.landedAt < 1.5) then
    dbg('packet %s: z %.2f speed %.3f %.3f %.3f, anim %d flags %d', st.speedZ and 'fall' or 'raksamp',
      data.position.z, data.moveSpeed.x, data.moveSpeed.y, data.moveSpeed.z, data.animationId, data.animationFlags)
  elseif surfing then
    local o = data.surfingOffsets
    dbg('packet surfing vehicle %d: %.2f %.2f %.2f, offsets %.2f %.2f %.2f', sv.id, data.position.x, data.position.y,
      data.position.z, o.x, o.y, o.z)
  end
end

function sampev.onApplyPlayerAnimation(playerId, lib, name, delta, loop, lockX, lockY, freeze, time)
  if playerId ~= getBotId() then return end
  dbg('ApplyAnimation %s:%s delta %.2f loop %s lock %s %s freeze %s time %d', lib, name, delta,
    tostring(loop), tostring(lockX), tostring(lockY), tostring(freeze), time)
end

function sampev.onClearPlayerAnimation(playerId)
  if playerId ~= getBotId() then return end
  dbg('ClearAnimations')
end

function sampev.onCreateObject(id, data)
  if not map then return end
  local av, ao = data.attachToVehicleId, data.attachToObjectId
  if (av and av ~= 65535) or (ao and ao ~= 65535) then
    map:removeObject(id)
    return
  end
  local p, r = data.position, data.rotation or {}
  st.created = st.created + 1
  if not map:addObject(id, data.modelId, p.x, p.y, p.z, r.x, r.y, r.z) then
    st.noCollision = st.noCollision + 1
    if map:modelInGame(data.modelId) then
      dbg('CreateObject %d model %d at %.2f %.2f %.2f: walk-through, the model has no collision in GTA either', id,
        data.modelId, p.x, p.y, p.z)
    else
      problem('object ' .. id .. ' ' .. data.modelId, 'CreateObject %d model %d at %.2f %.2f %.2f: the model is not in the game files, its collision is unknown - the bot walks through it',
        id, data.modelId, p.x, p.y, p.z)
    end
  end
end

local function riddenId()
  local a = st.body and st.body.anchor or st.restOn
  return a and a.id
end

function sampev.onVehicleStreamIn(id, data)
  if not map then return end
  local p = data.position
  if riddenId() == id then dbg('ridden vehicle %d streamed in again at %.2f %.2f %.2f', id, p.x, p.y, p.z) end
  if not map:setVehicle(id, data.type, p.x, p.y, p.z, colmap.headingRotation(data.rotation), data.interiorId) then
    if map:modelInGame(data.type) then
      dbg('vehicle %d model %d at %.2f %.2f %.2f: the model has no collision in GTA either, the bot passes through it', id,
        data.type, p.x, p.y, p.z)
    else
      problem('vehicle model ' .. data.type, 'vehicle %d model %d at %.2f %.2f %.2f is not in the game files: no collision, the bot passes through it',
        id, data.type, p.x, p.y, p.z)
    end
  end
end

function sampev.onVehicleStreamOut(id)
  if not map then return end
  if riddenId() == id then dbg('ridden vehicle %d streamed out', id) end
  map:removeVehicle(id)
end

local function poolVector(v, a, b, c)
  if not v then return nil end
  if v[a] then return v[a], v[b], v[c] end
  return v[1], v[2], v[3]
end

local function adoptVehicle(id, reason, known)
  known = known or getVehicle and getVehicle(id)
  if not known or not known.model then return false end
  local x, y, z = poolVector(known.position, 'x', 'y', 'z')
  if not x then return false end
  local q = known.quaternion
  local R = q and colmap.quatRotation(q.w or q[1], q.x or q[2], q.y or q[3], q.z or q[4]) or colmap.headingRotation(0)
  if not map:setVehicle(id, known.model, x, y, z, R, map.interior) then return false end
  log('vehicle %d model %d at %.2f %.2f %.2f taken from the RakSAMP vehicle pool: %s', id, known.model, x, y, z, reason)
  return true
end

if map and getAllVehicles then
  for id, known in pairs(getAllVehicles() or {}) do
    if not map.vehicles[id] then adoptVehicle(id, 'streamed in before slapfix started', known) end
  end
end

local function vehicleUpdate(source, id, p, R, speed)
  if riddenId() == id then
    local px, py, pz = map:vehiclePredicted(id, now())
    if px then
      local jump = math.sqrt((p.x - px) ^ 2 + (p.y - py) ^ 2 + (p.z - pz) ^ 2)
      dbg('ridden vehicle %d %s: %.2f %.2f %.2f speed %s, %.2f m off the predicted position%s', id, source,
        p.x, p.y, p.z, speed and ('%.3f %.3f %.3f'):format(speed.x, speed.y, speed.z) or 'none', jump,
        jump > RIDE_JUMP_LOG and (R and ' - a sync correction, the bot moves with the vehicle'
          or ' - a teleport, the bot stays in place') or '')
    end
  end
  if not map:moveVehicle(id, p.x, p.y, p.z, R, speed, now())
      and not (adoptVehicle(id, source .. ' before its stream-in reached slapfix') and map:moveVehicle(id, p.x, p.y, p.z, R, speed, now())) then
    problem('sync ' .. source .. ' ' .. id, '%s for vehicle %d that is not streamed in for the bot: it has no collision until it streams in',
      source, id)
    return
  end
  if not R then
    local v = map.vehicles[id]
    if v then v.teleports = v.teleports + 1 end
  end
end

function sampev.onVehicleSync(playerId, vehicleId, data)
  if not map then return end
  map:removePed(playerId)
  local q = data.quaternion
  vehicleUpdate('driver sync', vehicleId, data.position, colmap.quatRotation(q[1], q[2], q[3], q[4]), data.moveSpeed)
  map:setVehicleDriver(vehicleId, playerId)
  local sh = shooter(playerId)
  local fire = math.floor((data.keysData or 0) / blast.KEY_FIRE) % 2 == 1
  local v = map.vehicles[vehicleId]
  local t = now()
  if fire and not sh.carFire and v and v.modelId == blast.TANK_MODEL and t - (sh.tankAt or -math.huge) > blast.TANK_RELOAD then
    sh.tankAt = t
    tankShot(playerId, v, sh, t)
  end
  sh.carFire = fire
end

function sampev.onPassengerSync(playerId)
  if map then map:removePed(playerId) end
end

function sampev.onUnoccupiedSync(playerId, data)
  if not map then return end
  local r, f = data.roll, data.direction
  vehicleUpdate('unoccupied sync', data.vehicleId, data.position, colmap.axesRotation(r.x, r.y, r.z, f.x, f.y, f.z),
    data.moveSpeed)
  map:setVehicleDriver(data.vehicleId, nil)
end

function sampev.onTrailerSync(playerId, data)
  if not map then return end
  local q = data.quaternion
  vehicleUpdate('trailer sync', data.trailerId, data.position, colmap.quatRotation(q[0], q[1], q[2], q[3]),
    data.moveSpeed)
  map:setVehicleDriver(data.trailerId, playerId)
end

function sampev.onSetVehiclePosition(id, pos)
  local v = map and map.vehicles[id]
  if v then vehicleUpdate('SetVehiclePos', id, pos, nil, nil) end
end

function sampev.onSetVehicleAngle(id, angle)
  local v = map and map.vehicles[id]
  if v then map:moveVehicle(id, v.x, v.y, v.z, colmap.headingRotation(angle), { x = v.svx, y = v.svy, z = v.svz }, now()) end
end

function sampev.onLinkVehicleToInterior(id, interior)
  if map then map:setVehicleInterior(id, interior) end
end

function sampev.onPlayerStreamIn(playerId, team, model, position)
  if map then map:setPed(playerId, position.x, position.y, position.z) end
end

function sampev.onPlayerSync(playerId, data)
  if not map then return end
  map:playerLeftVehicles(playerId)
  map:setPed(playerId, data.position.x, data.position.y, data.position.z, data.moveSpeed)
  local sh = shooter(playerId)
  local fire = math.floor((data.keysData or 0) / blast.KEY_FIRE) % 2 == 1
  local weapon = (data.weapon or 0) % 64
  local t = now()
  if fire and not sh.fire and blast.ROCKETS[weapon] then
    local aim = freshAim(sh, t)
    if aim then
      local f, c, p = aim.camFront, aim.camPos, data.position
      local along = (p.x - c.x) * f.x + (p.y - c.y) * f.y + (p.z - c.z) * f.z
      fireRocket(playerId, weapon, c.x + f.x * along, c.y + f.y * along, c.z + f.z * along, f.x, f.y, f.z, t)
    else
      problem('rocket aim ' .. playerId, 'player %d fires weapon %d without a recent aim sync: the rocket is not simulated',
        playerId, weapon)
    end
  end
  sh.pos = { x = data.position.x, y = data.position.y, z = data.position.z }
  local q = data.quaternion
  if q then sh.R = colmap.quatRotation(q[1], q[2], q[3], q[4]) end
  sh.syncAt = t
  sh.spray = fight.SPRAYS[weapon] and weapon or nil
  local attack = fight.ATTACKS[data.animationId or 0]
  if attack and attack[2] ~= fight.GROUND and fight.COMBOS[attack[1]].hit[attack[2]] then
    local fresh = data.animationId ~= sh.attackAnim or (fire and not sh.fire and t >= (sh.attackHitAt or 0))
    if fresh then
      local at = t + fight.COMBOS[attack[1]].hit[attack[2]] * fight.FRAME
      sh.melee = { combo = attack[1], move = attack[2], at = at }
      sh.attackHitAt = at
    end
  end
  sh.attackAnim = data.animationId
  if fire and not sh.fire then
    if blast.THROWN[weapon] and not sh.throwAt then
      sh.throwWeapon, sh.throwPress, sh.throwRelease = weapon, t, nil
      sh.throwAt = t + blast.THROW_START + blast.THROW_FIRE
    elseif weapon == blast.DETONATOR then
      detonate(playerId)
    end
  elseif not fire and sh.fire and sh.throwAt and not sh.throwRelease then
    sh.throwRelease = t
  end
  sh.fire = fire
end

function sampev.onAimSync(playerId, data)
  local sh = shooter(playerId)
  sh.aim = { camFront = { x = data.camFront.x, y = data.camFront.y, z = data.camFront.z },
             camPos = { x = data.camPos.x, y = data.camPos.y, z = data.camPos.z } }
  sh.aimAt = now()
end

function sampev.onBulletSync(playerId, data)
  if not map then return end
  bulletHit(playerId, data, now())
end

function sampev.onCreateExplosion(p, style, radius)
  explosion(p.x, p.y, p.z, style, ('CreateExplosion, radius %.1f'):format(radius or 0))
end

function sampev.onPlayerStreamOut(playerId)
  shooters[playerId] = nil
  if not map then return end
  map:playerLeftVehicles(playerId)
  map:removePed(playerId)
end

function sampev.onDestroyObject(id)
  st.destroyed = st.destroyed + 1
  if map then map:removeObject(id) end
end

function sampev.onSetObjectPosition(id, pos)
  if map then map:setObjectPos(id, pos.x, pos.y, pos.z) end
end

function sampev.onSetObjectRotation(id, rot)
  if map then map:setObjectRot(id, rot.x, rot.y, rot.z) end
end

function sampev.onMoveObject(id, from, dest, speed, rot)
  if not map then return end
  if from then map:setObjectPos(id, from.x, from.y, from.z) end
  map:moveObject(id, dest.x, dest.y, dest.z, speed, rot and rot.x, rot and rot.y, rot and rot.z)
end

function sampev.onStopObject(id)
  if map then map:stopObject(id) end
end

function sampev.onRemoveBuilding(model, pos, radius)
  st.removed = st.removed + 1
  if map then map:removeBuilding(model, pos.x, pos.y, pos.z, radius) end
end

function sampev.onInitGame(playerId, hostName, settings)
  if settings and settings.normalOnfootSendrate and settings.normalOnfootSendrate > 0 then
    st.onfootRate = settings.normalOnfootSendrate
  end
  if settings and settings.gravity then phys.GRAVITY = settings.gravity end
  if map then
    local n, lo, hi = map:objectIds()
    dbg('InitGame: %d objects already held%s, kept as the SA-MP client keeps them', n,
      n > 0 and (' (ids %d..%d)'):format(lo, hi) or '')
  end
end

function sampev.onGamemodeRestart()
  if not map then return end
  local n = map:objectIds()
  dbg('GameModeRestart: %d objects and the vehicles are dropped, as the SA-MP client drops them', n)
  st.pending, st.drop, st.placed, st.restOn, st.body = nil, nil, nil, nil, nil
  map:clearObjects()
end

registerHandler('onDisconnect', function()
  st.pending, st.drop, st.placed, st.restOn, st.body, st.frozen = nil, nil, nil, nil, nil, false
  phys.GRAVITY = DEFAULT_GRAVITY
  if map then map:reset() end
end)

function onRunCommand(cmd)
  local name, arg = cmd:match('^(%S+)%s*(.-)%s*$')
  if name == '!gz' then
    if not map then
      print('[slapfix] no map')
      return true
    end
    local x, y, z = getBotPosition()
    print(('[slapfix] %.2f %.2f %.2f, map interior %d: %s'):format(x, y, z, map.interior,
      describe(map:probe(x, y, z + 0.5))))
    surroundings(x, y, z)
    return true
  elseif name == '!slaptest' then
    local x, y, z = getBotPosition()
    local h = tonumber(arg) or 5
    setBotPosition(x, y, z + h)
    st.pending = nil
    startDrop(x, y, z + h)
    return true
  elseif name == '!slapfix' then
    if arg == 'on' or arg == 'off' then
      CFG.enabled = arg == 'on'
      if not CFG.enabled then st.pending, st.drop, st.body = nil, nil, nil end
    elseif arg == 'debug' then
      CFG.debug = not CFG.debug
      print('[slapfix] debug ' .. (CFG.debug and 'on' or 'off'))
    elseif arg == 'stat' and map then
      local s = map:stats()
      print(('[slapfix] map %.0f KB, models %d (%.0f KB), objects %d, removed buildings %d, Lua heap %.0f KB')
        :format(s.mapBytes / 1024, s.models, s.modelBytes / 1024, s.objects, s.removals,
          collectgarbage('count')))
    end
    print('[slapfix] ' .. (CFG.enabled and 'on' or 'off'))
    return true
  end
end

for name, handler in pairs(sampev) do
  if type(handler) == 'function' and name:match('^on%u') then sampev[name] = guard(handler) end
end
onRunCommand = guard(onRunCommand)

for line in ([==[

  ____    ___   _____  _____  ___  _  __
 / ___|  / _ \ |  ___||_   _||_ _|| |/ /
 \___ \ | | | || |_     | |   | | | ' /
  ___) || |_| ||  _|    | |   | | | . \
 |____/  \___/ |_|      |_|  |___||_|\_\

  ___  _   _   ___   _   _  ___  ____   ___  _____   ___   ____
 |_ _|| \ | | / _ \ | | | ||_ _|/ ___| |_ _||_   _| / _ \ |  _ \
  | | |  \| || | | || | | | | | \___ \  | |   | |  | | | || |_) |
  | | | |\  || |_| || |_| | | |  ___) | | |   | |  | |_| ||  _ <
 |___||_| \_| \__\_\ \___/ |___||____/ |___|  |_|   \___/ |_| \_\

        SlapFix + MinorFixes  --  https://vk.ru/miurawr
]==] .. '\n'):gmatch('([^\n]*)\n') do print(line) end

emit('[slapfix] loaded. Author: Softik_Inquisitor (https://vk.ru/miurawr)')
